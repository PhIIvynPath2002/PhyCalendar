import http from 'node:http';
import { readFileSync, existsSync, mkdirSync } from 'node:fs';
import { resolve, dirname, extname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { randomBytes, scryptSync, timingSafeEqual, randomUUID } from 'node:crypto';
import { DatabaseSync } from 'node:sqlite';
import { validateSubscription, validDate, addDays, nextBoundary } from './public/core.js';
const root=dirname(fileURLToPath(import.meta.url));
const dir=resolve(process.env.DATA_DIR||resolve(root,'data'));mkdirSync(dir,{recursive:true,mode:0o700});
const authFile=resolve(dir,'auth.json');
if(!existsSync(authFile)){console.error('请先运行 npm run setup 设置个人密码。');process.exit(1);}
const auth=JSON.parse(readFileSync(authFile,'utf8'));
const db=new DatabaseSync(resolve(dir,'calendar.sqlite')); db.exec('PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL; CREATE TABLE IF NOT EXISTS state (id INTEGER PRIMARY KEY CHECK(id=1), revision INTEGER NOT NULL, json TEXT NOT NULL);');
db.prepare('INSERT OR IGNORE INTO state VALUES(1,0,?)').run(JSON.stringify({subscriptions:[],payments:[]}));
const sessions=new Map(), attempts=new Map();
const secure=process.env.COOKIE_SECURE==='true';
const port=Number(process.env.PORT||3000),host=process.env.HOST||'127.0.0.1';
function snapshot(){const r=db.prepare('SELECT * FROM state WHERE id=1').get();return {...JSON.parse(r.json),revision:r.revision};}
function save(data,revision){ const r=db.prepare('UPDATE state SET revision=revision+1,json=? WHERE id=1 AND revision=?').run(JSON.stringify({subscriptions:data.subscriptions,payments:data.payments}),revision); if(!r.changes)throw Object.assign(Error('另一台设备已修改数据。请刷新后重新操作，避免覆盖。'),{status:409});return snapshot();}
function validId(x){return typeof x==='string'&&/^[a-zA-Z0-9-]{1,80}$/.test(x);}
function validateBackup(b){
 if(b.version!==1||!Array.isArray(b.subscriptions)||!Array.isArray(b.payments)||b.subscriptions.length>2000||b.payments.length>50000)throw Error('备份格式无效或记录过多');
 const ids=new Set(),pids=new Set();
 const subscriptions=b.subscriptions.map(x=>{if(!validId(x.id)||!validId(x.scheduleId)||ids.has(x.id))throw Error('订阅编号无效或重复');ids.add(x.id);return {...validateSubscription(x),scheduleId:x.scheduleId};});
 const keys=new Set();
 const payments=b.payments.map(p=>{
  if(!validId(p.id)||pids.has(p.id)||!validId(p.subscriptionId)||!validId(p.scheduleId)||!validDate(p.dueDate)||!validDate(p.paidDate)||!validDate(p.periodStart)||!validDate(p.periodEnd)||p.periodEnd<p.periodStart||!['CNY','USD'].includes(p.currency)||typeof p.name!=='string'||!p.name.trim()||p.name.length>100||typeof p.amount!=='number'||!Number.isFinite(p.amount)||p.amount<0||p.amount>100000000||Math.abs(p.amount*100-Math.round(p.amount*100))>0.00001)throw Error('付款记录格式无效');
  const key=`${p.subscriptionId}:${p.scheduleId}:${p.dueDate}`;if(keys.has(key))throw Error('备份包含重复周期付款');keys.add(key);pids.add(p.id);
  return {id:p.id,subscriptionId:p.subscriptionId,scheduleId:p.scheduleId,name:p.name,dueDate:p.dueDate,paidDate:p.paidDate,periodStart:p.periodStart,periodEnd:p.periodEnd,amount:p.amount,currency:p.currency};
 });return {subscriptions,payments};
}
async function body(req){let raw='';for await(const chunk of req){raw+=chunk;if(Buffer.byteLength(raw)>8*1024*1024)throw Object.assign(Error('请求过大，最多 8 MB'),{status:413});}try{return JSON.parse(raw||'{}');}catch{throw Error('JSON 格式不正确');}}
function cookie(req){const token=(req.headers.cookie||'').split(';').map(x=>x.trim()).find(x=>x.startsWith('session='))?.slice(8);const s=sessions.get(token);if(s&&s.expires>Date.now())return {token,...s};if(token)sessions.delete(token);return null;}
function json(res,status,data){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(data));}
const server=http.createServer(async(req,res)=>{
 res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','no-referrer');res.setHeader('X-Frame-Options','DENY');
 res.setHeader('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; manifest-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'");
 if(secure)res.setHeader('Strict-Transport-Security','max-age=31536000');
 const path=new URL(req.url,'http://localhost').pathname;
 try{
  if(path.startsWith('/api/')){
   if(req.method!=='GET'){
    if(req.headers['x-requested-with']!=='PhyCalendar')return json(res,403,{error:'请求来源无效'});
    if(req.headers.origin){const expected=process.env.PUBLIC_ORIGIN||`http://${req.headers.host}`;if(req.headers.origin!==expected)return json(res,403,{error:'请求来源不匹配，请检查 PUBLIC_ORIGIN 配置'});}
   }
   if(path==='/api/login'&&req.method==='POST'){
    const ip=req.socket.remoteAddress; const now=Date.now(); let a=attempts.get(ip);if(!a||now>a.until){a={count:0,until:now+15*60e3};attempts.set(ip,a);}if(a.count>=10)return json(res,429,{error:'尝试次数过多，请 15 分钟后重试'});
    const b=await body(req);a.count++;const pw=typeof b.password==='string'?b.password:'';
    if(pw.length>1024||!timingSafeEqual(scryptSync(pw,auth.salt,64),Buffer.from(auth.hash,'hex')))return json(res,401,{error:'密码不正确'});
    attempts.delete(ip);for(const [t,s]of sessions)if(s.expires<now)sessions.delete(t);
    if(sessions.size>1000)sessions.delete(sessions.keys().next().value);
    const token=randomBytes(32).toString('hex'),csrf=randomBytes(24).toString('hex');sessions.set(token,{csrf,expires:now+7*86400e3});
    res.setHeader('Set-Cookie',`session=${token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=604800${secure?'; Secure':''}`);return json(res,200,{csrf});
   }
   const session=cookie(req);if(!session)return json(res,401,{error:'请先登录'});
   if(path==='/api/session'&&req.method==='GET')return json(res,200,{csrf:session.csrf});
   if(req.method!=='GET'&&req.headers['x-csrf-token']!==session.csrf)return json(res,403,{error:'安全校验失败，请重新登录'});
   if(path==='/api/logout'&&req.method==='POST'){sessions.delete(session.token);res.setHeader('Set-Cookie',`session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0${secure?'; Secure':''}`);return json(res,200,{ok:true});}
   if(path==='/api/data'&&req.method==='GET')return json(res,200,snapshot());
   if(path==='/api/backup'&&req.method==='GET'){res.setHeader('Content-Disposition','attachment; filename="phycalendar-backup.json"');return json(res,200,{version:1,exportedAt:new Date().toISOString(),...snapshot()});}
   const b=await body(req),state=snapshot();if(b.revision!==state.revision)return json(res,409,{error:'另一台设备已修改数据。请刷新后重新操作，避免覆盖。'});
   if(path==='/api/subscriptions'&&req.method==='POST'){
    const s=validateSubscription(b.subscription),old=state.subscriptions.find(x=>x.id===s.id);
    if(s.id&&!old)throw Error('订阅不存在');
    const scheduleChanged=old&&(old.dueDate!==s.dueDate||old.cycle!==s.cycle||(s.cycle==='custom'&&old.customDays!==s.customDays));
    const item={...s,id:old?.id||randomUUID(),scheduleId:!old||scheduleChanged?randomUUID():old.scheduleId};
    if(old)state.subscriptions=state.subscriptions.map(x=>x.id===item.id?item:x);else {if(state.subscriptions.length>=2000)throw Error('最多保存 2000 个订阅');state.subscriptions.push(item);}
    return json(res,200,save(state,b.revision));
   }
   if(path==='/api/subscriptions/delete'&&req.method==='POST'){
    state.subscriptions=state.subscriptions.filter(s=>s.id!==b.id);return json(res,200,save(state,b.revision));
   }
   if(path==='/api/payments'&&req.method==='POST'){
    const s=state.subscriptions.find(x=>x.id===b.subscriptionId);if(!s)throw Error('订阅不存在');
    if(!validDate(b.dueDate)||!validDate(b.paidDate)||!Number.isFinite(b.amount)||b.amount<0||b.amount>1e8||Math.abs(b.amount*100-Math.round(b.amount*100))>0.00001)throw Error('付款日期或金额无效');
    if(b.dueDate<s.dueDate || (s.cycle==='once' ? b.dueDate!==s.dueDate : nextBoundary(s,addDays(b.dueDate,-1))!==b.dueDate))throw Error('请选择计划中的周期日期');
    if(state.payments.some(p=>p.subscriptionId===s.id&&p.scheduleId===s.scheduleId&&p.dueDate===b.dueDate))throw Error('此周期已经确认付款，请勿重复记录');
    state.payments.push({id:randomUUID(),subscriptionId:s.id,scheduleId:s.scheduleId,name:s.name,dueDate:b.dueDate,paidDate:b.paidDate,amount:b.amount,currency:s.currency,periodStart:b.dueDate,periodEnd:nextBoundary(s,b.dueDate)||b.dueDate});return json(res,200,save(state,b.revision));
   }
   if(path==='/api/payments/delete'&&req.method==='POST'){state.payments=state.payments.filter(p=>p.id!==b.id);return json(res,200,save(state,b.revision));}
   if(path==='/api/import'&&req.method==='POST')return json(res,200,save(validateBackup(b.backup),b.revision));
   return json(res,404,{error:'接口不存在'});
  }
  if(req.method!=='GET'&&req.method!=='HEAD'){res.writeHead(405);return res.end();}
  const names={'/':'index.html','/index.html':'index.html','/app.js':'app.js','/core.js':'core.js','/style.css':'style.css','/manifest.webmanifest':'manifest.webmanifest','/sw.js':'sw.js','/icon.svg':'icon.svg','/apple-touch-icon.png':'apple-touch-icon.png','/icon-192.png':'icon-192.png','/icon-512.png':'icon-512.png'};
  if(!names[path]){res.writeHead(404);return res.end('Not found');}
  const file=resolve(root,'public',names[path]);const mime={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.webmanifest':'application/manifest+json','.svg':'image/svg+xml','.png':'image/png'};
  res.writeHead(200,{'Content-Type':mime[extname(file)],'Cache-Control':'no-cache'});res.end(req.method==='HEAD'?undefined:readFileSync(file));
 }catch(e){json(res,e.status||400,{error:e.status===500?'服务器错误':e.message});}
});
server.listen(port,host,()=>console.log(`PhyCalendar listening on ${host}:${server.address().port}. Data: ${dir}`));
function close(){server.close(()=>{db.close();process.exit(0);});}process.on('SIGTERM',close);process.on('SIGINT',close);

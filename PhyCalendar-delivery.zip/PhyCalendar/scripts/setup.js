import { mkdirSync, existsSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { randomBytes, scryptSync } from 'node:crypto';
import { createInterface } from 'node:readline/promises';
const dir=resolve(process.env.DATA_DIR || 'data'); mkdirSync(dir,{recursive:true,mode:0o700});
const file=resolve(dir,'auth.json');
if(existsSync(file)) { console.log('登录密码已配置。要重设密码，请先停止服务，备份并删除 data/auth.json，再运行本命令。'); process.exit(0); }
const rl=createInterface({input:process.stdin,output:process.stdout});
console.log('此终端输入会显示，请在私密终端操作；不要使用其他网站的密码。');
const password=process.env.APP_PASSWORD || await rl.question('设置个人登录密码（至少 12 位）：'); rl.close();
if(password.length<12) { console.error('密码至少 12 位');process.exit(1); }
const salt=randomBytes(16).toString('hex');
writeFileSync(file,JSON.stringify({salt,hash:scryptSync(password,salt,64).toString('hex')}),{mode:0o600,flag:'wx'});
console.log('密码已安全散列保存。运行 npm start 启动应用。');

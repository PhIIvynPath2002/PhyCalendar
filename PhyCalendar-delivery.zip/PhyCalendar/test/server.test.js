import {test} from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,writeFileSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {spawn} from 'node:child_process';
import {randomBytes,scryptSync} from 'node:crypto';
import {once} from 'node:events';
test('真实服务器：鉴权、CRUD、付款去重、冲突、备份恢复与重启持久化',async()=>{
 const dir=mkdtempSync(join(tmpdir(),'phycalendar-test-')),salt=randomBytes(16).toString('hex'),password='test-only-password-123';
 writeFileSync(join(dir,'auth.json'),JSON.stringify({salt,hash:scryptSync(password,salt,64).toString('hex')}));
 let child,base,cookie='',csrf='';
 async function start(){child=spawn(process.execPath,['server.js'],{cwd:new URL('..',import.meta.url),env:{...process.env,DATA_DIR:dir,PORT:'0',HOST:'127.0.0.1'},stdio:['ignore','pipe','pipe']});let out='';child.stdout.on('data',b=>out+=b);child.stderr.on('data',b=>out+=b);await new Promise((resolve,reject)=>{const timeout=setTimeout(()=>reject(Error(out)),5000);child.stdout.on('data',()=>{const match=out.match(/listening on 127.0.0.1:(\d+)/);if(match){base='http://127.0.0.1:'+match[1];clearTimeout(timeout);resolve();}});child.once('exit',()=>{clearTimeout(timeout);reject(Error(out));});});}
 async function stop(){child.kill('SIGTERM');await once(child,'exit');}
 async function call(path,b,auth=true){const r=await fetch(base+'/api/'+path,{method:b?'POST':'GET',headers:{...(auth?{Cookie:cookie,'X-CSRF-Token':csrf}:{}),'X-Requested-With':'PhyCalendar','Content-Type':'application/json'},body:b?JSON.stringify(b):undefined});return {status:r.status,body:await r.json(),cookie:r.headers.get('set-cookie')};}
 async function login(){const r=await call('login',{password},false);assert.equal(r.status,200);assert.match(r.cookie,/HttpOnly/);cookie=r.cookie.split(';')[0];csrf=r.body.csrf;}
 try{
  await start();assert.equal((await call('data',null,false)).status,401);await login();let s=(await call('data')).body;assert.equal(s.revision,0);
  let r=await call('subscriptions',{revision:s.revision,subscription:{name:'真实保存测试',dueDate:'2026-01-31',amount:20,currency:'USD',cycle:'monthly',autoRenew:true}});assert.equal(r.status,200);s=r.body;const sub=s.subscriptions[0];
  assert.equal((await call('payments',{revision:s.revision,subscriptionId:sub.id,dueDate:'2026-02-27',paidDate:'2026-02-28',amount:20})).status,400);
  r=await call('payments',{revision:s.revision,subscriptionId:sub.id,dueDate:'2026-02-28',paidDate:'2026-02-28',amount:19});assert.equal(r.status,200);s=r.body;assert.equal(s.payments[0].periodEnd,'2026-03-31');
  assert.equal((await call('payments',{revision:s.revision,subscriptionId:sub.id,dueDate:'2026-02-28',paidDate:'2026-02-28',amount:19})).status,400);
  assert.equal((await call('subscriptions/delete',{revision:0,id:sub.id})).status,409);
  assert.equal((await fetch(base+'/api/subscriptions/delete',{method:'POST',headers:{Cookie:cookie,'Content-Type':'application/json'},body:JSON.stringify({revision:s.revision,id:sub.id})})).status,403);
  const backup=(await call('backup')).body;assert.equal(backup.version,1);
  r=await call('subscriptions',{revision:s.revision,subscription:{...sub,amount:99}});s=r.body;assert.equal(s.payments[0].amount,19);assert.equal(s.subscriptions[0].scheduleId,sub.scheduleId);
  r=await call('subscriptions/delete',{revision:s.revision,id:sub.id});s=r.body;assert.equal(s.subscriptions.length,0);assert.equal(s.payments.length,1);
  r=await call('import',{revision:s.revision,backup});assert.equal(r.status,200);s=r.body;assert.equal(s.subscriptions[0].amount,20);
  assert.equal((await call('import',{revision:s.revision,backup:{...backup,payments:[...backup.payments,...backup.payments]}})).status,400);
  await stop();await start();cookie='';csrf='';assert.equal((await call('data')).status,401);await login();const restored=(await call('data')).body;assert.deepEqual(restored,s);
  await call('logout',{});assert.equal((await call('data')).status,401);
 }finally{if(child&&child.exitCode===null)await stop();rmSync(dir,{recursive:true,force:true});}
});

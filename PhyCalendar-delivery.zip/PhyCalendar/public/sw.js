// Private records and API responses are never stored in the service-worker cache.
self.addEventListener('install',()=>self.skipWaiting());
self.addEventListener('activate',event=>event.waitUntil(self.clients.claim()));
self.addEventListener('fetch',event=>{
 if(event.request.mode==='navigate')event.respondWith(fetch(event.request).catch(()=>new Response('<!doctype html><html lang="zh-CN"><meta name="viewport" content="width=device-width,initial-scale=1"><meta charset="utf-8"><title>订阅日历 · 离线</title><h1>暂时无法连接订阅日历</h1><p>请检查网络与服务器，恢复连接后重新打开。私人记录未离线缓存。</p><a href="/">重新连接</a></html>',{headers:{'Content-Type':'text/html; charset=utf-8'}})));
});

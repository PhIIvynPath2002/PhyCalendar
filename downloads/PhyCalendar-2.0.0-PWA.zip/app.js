var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res, err) => function __init() {
  if (err) throw err[0];
  try {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  } catch (e) {
    throw err = [e], e;
  }
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// node_modules/@capacitor/core/dist/index.js
var ExceptionCode, CapacitorException, getPlatformId, createCapacitor, initCapacitorGlobal, Capacitor, registerPlugin, WebPlugin, encode, decode, CapacitorCookiesPluginWeb, CapacitorCookies, readBlobAsBase64, normalizeHttpHeaders, buildUrlParams, buildRequestInit, CapacitorHttpPluginWeb, CapacitorHttp, SystemBarsStyle, SystemBarType, SystemBarsPluginWeb, SystemBars;
var init_dist = __esm({
  "node_modules/@capacitor/core/dist/index.js"() {
    (function(ExceptionCode2) {
      ExceptionCode2["Unimplemented"] = "UNIMPLEMENTED";
      ExceptionCode2["Unavailable"] = "UNAVAILABLE";
    })(ExceptionCode || (ExceptionCode = {}));
    CapacitorException = class extends Error {
      constructor(message, code, data2) {
        super(message);
        this.message = message;
        this.code = code;
        this.data = data2;
      }
    };
    getPlatformId = (win) => {
      var _a, _b;
      if (win === null || win === void 0 ? void 0 : win.androidBridge) {
        return "android";
      } else if ((_b = (_a = win === null || win === void 0 ? void 0 : win.webkit) === null || _a === void 0 ? void 0 : _a.messageHandlers) === null || _b === void 0 ? void 0 : _b.bridge) {
        return "ios";
      } else {
        return "web";
      }
    };
    createCapacitor = (win) => {
      const capCustomPlatform = win.CapacitorCustomPlatform || null;
      const cap = win.Capacitor || {};
      const Plugins = cap.Plugins = cap.Plugins || {};
      const getPlatform = () => {
        return capCustomPlatform !== null ? capCustomPlatform.name : getPlatformId(win);
      };
      const isNativePlatform = () => getPlatform() !== "web";
      const isPluginAvailable = (pluginName) => {
        const plugin = registeredPlugins.get(pluginName);
        if (plugin === null || plugin === void 0 ? void 0 : plugin.platforms.has(getPlatform())) {
          return true;
        }
        if (getPluginHeader(pluginName)) {
          return true;
        }
        return false;
      };
      const getPluginHeader = (pluginName) => {
        var _a;
        return (_a = cap.PluginHeaders) === null || _a === void 0 ? void 0 : _a.find((h) => h.name === pluginName);
      };
      const handleError = (err) => win.console.error(err);
      const registeredPlugins = /* @__PURE__ */ new Map();
      const registerPlugin2 = (pluginName, jsImplementations = {}) => {
        const registeredPlugin = registeredPlugins.get(pluginName);
        if (registeredPlugin) {
          console.warn(`Capacitor plugin "${pluginName}" already registered. Cannot register plugins twice.`);
          return registeredPlugin.proxy;
        }
        const platform = getPlatform();
        const pluginHeader = getPluginHeader(pluginName);
        let jsImplementation;
        const loadPluginImplementation = async () => {
          if (!jsImplementation && platform in jsImplementations) {
            jsImplementation = typeof jsImplementations[platform] === "function" ? jsImplementation = await jsImplementations[platform]() : jsImplementation = jsImplementations[platform];
          } else if (capCustomPlatform !== null && !jsImplementation && "web" in jsImplementations) {
            jsImplementation = typeof jsImplementations["web"] === "function" ? jsImplementation = await jsImplementations["web"]() : jsImplementation = jsImplementations["web"];
          }
          return jsImplementation;
        };
        const createPluginMethod = (impl, prop) => {
          var _a, _b;
          if (pluginHeader) {
            const methodHeader = pluginHeader === null || pluginHeader === void 0 ? void 0 : pluginHeader.methods.find((m) => prop === m.name);
            if (methodHeader) {
              if (methodHeader.rtype === "promise") {
                return (options) => cap.nativePromise(pluginName, prop.toString(), options);
              } else {
                return (options, callback) => cap.nativeCallback(pluginName, prop.toString(), options, callback);
              }
            } else if (impl) {
              return (_a = impl[prop]) === null || _a === void 0 ? void 0 : _a.bind(impl);
            }
          } else if (impl) {
            return (_b = impl[prop]) === null || _b === void 0 ? void 0 : _b.bind(impl);
          } else {
            throw new CapacitorException(`"${pluginName}" plugin is not implemented on ${platform}`, ExceptionCode.Unimplemented);
          }
        };
        const createPluginMethodWrapper = (prop) => {
          let remove;
          const wrapper = (...args) => {
            const p = loadPluginImplementation().then((impl) => {
              const fn = createPluginMethod(impl, prop);
              if (fn) {
                const p2 = fn(...args);
                remove = p2 === null || p2 === void 0 ? void 0 : p2.remove;
                return p2;
              } else {
                throw new CapacitorException(`"${pluginName}.${prop}()" is not implemented on ${platform}`, ExceptionCode.Unimplemented);
              }
            });
            if (prop === "addListener") {
              p.remove = async () => remove();
            }
            return p;
          };
          wrapper.toString = () => `${prop.toString()}() { [capacitor code] }`;
          Object.defineProperty(wrapper, "name", {
            value: prop,
            writable: false,
            configurable: false
          });
          return wrapper;
        };
        const addListener = createPluginMethodWrapper("addListener");
        const removeListener = createPluginMethodWrapper("removeListener");
        const addListenerNative = (eventName, callback) => {
          const call = addListener({ eventName }, callback);
          const remove = async () => {
            const callbackId = await call;
            removeListener({
              eventName,
              callbackId
            }, callback);
          };
          const p = new Promise((resolve2) => call.then(() => resolve2({ remove })));
          p.remove = async () => {
            console.warn(`Using addListener() without 'await' is deprecated.`);
            await remove();
          };
          return p;
        };
        const proxy = new Proxy({}, {
          get(_, prop) {
            switch (prop) {
              // https://github.com/facebook/react/issues/20030
              case "$$typeof":
                return void 0;
              case "toJSON":
                return () => ({});
              case "addListener":
                return pluginHeader ? addListenerNative : addListener;
              case "removeListener":
                return removeListener;
              default:
                return createPluginMethodWrapper(prop);
            }
          }
        });
        Plugins[pluginName] = proxy;
        registeredPlugins.set(pluginName, {
          name: pluginName,
          proxy,
          platforms: /* @__PURE__ */ new Set([...Object.keys(jsImplementations), ...pluginHeader ? [platform] : []])
        });
        return proxy;
      };
      if (!cap.convertFileSrc) {
        cap.convertFileSrc = (filePath) => filePath;
      }
      cap.getPlatform = getPlatform;
      cap.handleError = handleError;
      cap.isNativePlatform = isNativePlatform;
      cap.isPluginAvailable = isPluginAvailable;
      cap.registerPlugin = registerPlugin2;
      cap.Exception = CapacitorException;
      cap.DEBUG = !!cap.DEBUG;
      cap.isLoggingEnabled = !!cap.isLoggingEnabled;
      return cap;
    };
    initCapacitorGlobal = (win) => win.Capacitor = createCapacitor(win);
    Capacitor = /* @__PURE__ */ initCapacitorGlobal(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : typeof global !== "undefined" ? global : {});
    registerPlugin = Capacitor.registerPlugin;
    WebPlugin = class {
      constructor() {
        this.listeners = {};
        this.retainedEventArguments = {};
        this.windowListeners = {};
      }
      addListener(eventName, listenerFunc) {
        let firstListener = false;
        const listeners = this.listeners[eventName];
        if (!listeners) {
          this.listeners[eventName] = [];
          firstListener = true;
        }
        this.listeners[eventName].push(listenerFunc);
        const windowListener = this.windowListeners[eventName];
        if (windowListener && !windowListener.registered) {
          this.addWindowListener(windowListener);
        }
        if (firstListener) {
          this.sendRetainedArgumentsForEvent(eventName);
        }
        const remove = async () => this.removeListener(eventName, listenerFunc);
        const p = Promise.resolve({ remove });
        return p;
      }
      async removeAllListeners() {
        this.listeners = {};
        for (const listener in this.windowListeners) {
          this.removeWindowListener(this.windowListeners[listener]);
        }
        this.windowListeners = {};
      }
      notifyListeners(eventName, data2, retainUntilConsumed) {
        const listeners = this.listeners[eventName];
        if (!listeners) {
          if (retainUntilConsumed) {
            let args = this.retainedEventArguments[eventName];
            if (!args) {
              args = [];
            }
            args.push(data2);
            this.retainedEventArguments[eventName] = args;
          }
          return;
        }
        listeners.forEach((listener) => listener(data2));
      }
      hasListeners(eventName) {
        var _a;
        return !!((_a = this.listeners[eventName]) === null || _a === void 0 ? void 0 : _a.length);
      }
      registerWindowListener(windowEventName, pluginEventName) {
        this.windowListeners[pluginEventName] = {
          registered: false,
          windowEventName,
          pluginEventName,
          handler: (event) => {
            this.notifyListeners(pluginEventName, event);
          }
        };
      }
      unimplemented(msg = "not implemented") {
        return new Capacitor.Exception(msg, ExceptionCode.Unimplemented);
      }
      unavailable(msg = "not available") {
        return new Capacitor.Exception(msg, ExceptionCode.Unavailable);
      }
      async removeListener(eventName, listenerFunc) {
        const listeners = this.listeners[eventName];
        if (!listeners) {
          return;
        }
        const index = listeners.indexOf(listenerFunc);
        if (index !== -1) {
          this.listeners[eventName].splice(index, 1);
        }
        if (!this.listeners[eventName].length) {
          this.removeWindowListener(this.windowListeners[eventName]);
        }
      }
      addWindowListener(handle) {
        window.addEventListener(handle.windowEventName, handle.handler);
        handle.registered = true;
      }
      removeWindowListener(handle) {
        if (!handle) {
          return;
        }
        window.removeEventListener(handle.windowEventName, handle.handler);
        handle.registered = false;
      }
      sendRetainedArgumentsForEvent(eventName) {
        const args = this.retainedEventArguments[eventName];
        if (!args) {
          return;
        }
        delete this.retainedEventArguments[eventName];
        args.forEach((arg) => {
          this.notifyListeners(eventName, arg);
        });
      }
    };
    encode = (str) => encodeURIComponent(str).replace(/%(2[346B]|5E|60|7C)/g, decodeURIComponent).replace(/[()]/g, escape);
    decode = (str) => str.replace(/(%[\dA-F]{2})+/gi, decodeURIComponent);
    CapacitorCookiesPluginWeb = class extends WebPlugin {
      async getCookies() {
        const cookies = document.cookie;
        const cookieMap = {};
        cookies.split(";").forEach((cookie) => {
          if (cookie.length <= 0)
            return;
          let [key, value] = cookie.replace(/=/, "CAP_COOKIE").split("CAP_COOKIE");
          key = decode(key).trim();
          value = decode(value).trim();
          cookieMap[key] = value;
        });
        return cookieMap;
      }
      async setCookie(options) {
        try {
          const encodedKey = encode(options.key);
          const encodedValue = encode(options.value);
          const expires = options.expires ? `; expires=${options.expires.replace("expires=", "")}` : "";
          const path = (options.path || "/").replace("path=", "");
          const domain = options.url != null && options.url.length > 0 ? `domain=${options.url}` : "";
          document.cookie = `${encodedKey}=${encodedValue || ""}${expires}; path=${path}; ${domain};`;
        } catch (error) {
          return Promise.reject(error);
        }
      }
      async deleteCookie(options) {
        try {
          document.cookie = `${options.key}=; Max-Age=0`;
        } catch (error) {
          return Promise.reject(error);
        }
      }
      async clearCookies() {
        try {
          const cookies = document.cookie.split(";") || [];
          for (const cookie of cookies) {
            document.cookie = cookie.replace(/^ +/, "").replace(/=.*/, `=;expires=${(/* @__PURE__ */ new Date()).toUTCString()};path=/`);
          }
        } catch (error) {
          return Promise.reject(error);
        }
      }
      async clearAllCookies() {
        try {
          await this.clearCookies();
        } catch (error) {
          return Promise.reject(error);
        }
      }
    };
    CapacitorCookies = registerPlugin("CapacitorCookies", {
      web: () => new CapacitorCookiesPluginWeb()
    });
    readBlobAsBase64 = async (blob) => new Promise((resolve2, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        const base64String = reader.result;
        resolve2(base64String.indexOf(",") >= 0 ? base64String.split(",")[1] : base64String);
      };
      reader.onerror = (error) => reject(error);
      reader.readAsDataURL(blob);
    });
    normalizeHttpHeaders = (headers = {}) => {
      const originalKeys = Object.keys(headers);
      const loweredKeys = Object.keys(headers).map((k) => k.toLocaleLowerCase());
      const normalized = loweredKeys.reduce((acc, key, index) => {
        acc[key] = headers[originalKeys[index]];
        return acc;
      }, {});
      return normalized;
    };
    buildUrlParams = (params, shouldEncode = true) => {
      if (!params)
        return null;
      const output = Object.entries(params).reduce((accumulator, entry) => {
        const [key, value] = entry;
        let encodedValue;
        let item;
        if (Array.isArray(value)) {
          item = "";
          value.forEach((str) => {
            encodedValue = shouldEncode ? encodeURIComponent(str) : str;
            item += `${key}=${encodedValue}&`;
          });
          item.slice(0, -1);
        } else {
          encodedValue = shouldEncode ? encodeURIComponent(value) : value;
          item = `${key}=${encodedValue}`;
        }
        return `${accumulator}&${item}`;
      }, "");
      return output.substr(1);
    };
    buildRequestInit = (options, extra = {}) => {
      const output = Object.assign({ method: options.method || "GET", headers: options.headers }, extra);
      const headers = normalizeHttpHeaders(options.headers);
      const type = headers["content-type"] || "";
      if (typeof options.data === "string") {
        output.body = options.data;
      } else if (type.includes("application/x-www-form-urlencoded")) {
        const params = new URLSearchParams();
        for (const [key, value] of Object.entries(options.data || {})) {
          params.set(key, value);
        }
        output.body = params.toString();
      } else if (type.includes("multipart/form-data") || options.data instanceof FormData) {
        const form = new FormData();
        if (options.data instanceof FormData) {
          options.data.forEach((value, key) => {
            form.append(key, value);
          });
        } else {
          for (const key of Object.keys(options.data)) {
            form.append(key, options.data[key]);
          }
        }
        output.body = form;
        const headers2 = new Headers(output.headers);
        headers2.delete("content-type");
        output.headers = headers2;
      } else if (type.includes("application/json") || typeof options.data === "object") {
        output.body = JSON.stringify(options.data);
      }
      return output;
    };
    CapacitorHttpPluginWeb = class extends WebPlugin {
      /**
       * Perform an Http request given a set of options
       * @param options Options to build the HTTP request
       */
      async request(options) {
        const requestInit = buildRequestInit(options, options.webFetchExtra);
        const urlParams = buildUrlParams(options.params, options.shouldEncodeUrlParams);
        const url = urlParams ? `${options.url}?${urlParams}` : options.url;
        const response = await fetch(url, requestInit);
        const contentType = response.headers.get("content-type") || "";
        let { responseType = "text" } = response.ok ? options : {};
        if (contentType.includes("application/json")) {
          responseType = "json";
        }
        let data2;
        let blob;
        switch (responseType) {
          case "arraybuffer":
          case "blob":
            blob = await response.blob();
            data2 = await readBlobAsBase64(blob);
            break;
          case "json":
            data2 = await response.json();
            break;
          case "document":
          case "text":
          default:
            data2 = await response.text();
        }
        const headers = {};
        response.headers.forEach((value, key) => {
          headers[key] = value;
        });
        return {
          data: data2,
          headers,
          status: response.status,
          url: response.url
        };
      }
      /**
       * Perform an Http GET request given a set of options
       * @param options Options to build the HTTP request
       */
      async get(options) {
        return this.request(Object.assign(Object.assign({}, options), { method: "GET" }));
      }
      /**
       * Perform an Http POST request given a set of options
       * @param options Options to build the HTTP request
       */
      async post(options) {
        return this.request(Object.assign(Object.assign({}, options), { method: "POST" }));
      }
      /**
       * Perform an Http PUT request given a set of options
       * @param options Options to build the HTTP request
       */
      async put(options) {
        return this.request(Object.assign(Object.assign({}, options), { method: "PUT" }));
      }
      /**
       * Perform an Http PATCH request given a set of options
       * @param options Options to build the HTTP request
       */
      async patch(options) {
        return this.request(Object.assign(Object.assign({}, options), { method: "PATCH" }));
      }
      /**
       * Perform an Http DELETE request given a set of options
       * @param options Options to build the HTTP request
       */
      async delete(options) {
        return this.request(Object.assign(Object.assign({}, options), { method: "DELETE" }));
      }
    };
    CapacitorHttp = registerPlugin("CapacitorHttp", {
      web: () => new CapacitorHttpPluginWeb()
    });
    (function(SystemBarsStyle2) {
      SystemBarsStyle2["Dark"] = "DARK";
      SystemBarsStyle2["Light"] = "LIGHT";
      SystemBarsStyle2["Default"] = "DEFAULT";
    })(SystemBarsStyle || (SystemBarsStyle = {}));
    (function(SystemBarType2) {
      SystemBarType2["StatusBar"] = "StatusBar";
      SystemBarType2["NavigationBar"] = "NavigationBar";
    })(SystemBarType || (SystemBarType = {}));
    SystemBarsPluginWeb = class extends WebPlugin {
      async setStyle() {
        this.unavailable("not available for web");
      }
      async setAnimation() {
        this.unavailable("not available for web");
      }
      async show() {
        this.unavailable("not available for web");
      }
      async hide() {
        this.unavailable("not available for web");
      }
    };
    SystemBars = registerPlugin("SystemBars", {
      web: () => new SystemBarsPluginWeb()
    });
  }
});

// node_modules/@capacitor/preferences/dist/esm/web.js
var web_exports = {};
__export(web_exports, {
  PreferencesWeb: () => PreferencesWeb
});
var PreferencesWeb;
var init_web = __esm({
  "node_modules/@capacitor/preferences/dist/esm/web.js"() {
    init_dist();
    PreferencesWeb = class extends WebPlugin {
      constructor() {
        super(...arguments);
        this.group = "CapacitorStorage";
      }
      async configure({ group }) {
        if (typeof group === "string") {
          this.group = group;
        }
      }
      async get(options) {
        const value = this.impl.getItem(this.applyPrefix(options.key));
        return { value };
      }
      async set(options) {
        this.impl.setItem(this.applyPrefix(options.key), options.value);
      }
      async remove(options) {
        this.impl.removeItem(this.applyPrefix(options.key));
      }
      async keys() {
        const keys = this.rawKeys().map((k) => k.substring(this.prefix.length));
        return { keys };
      }
      async clear() {
        for (const key of this.rawKeys()) {
          this.impl.removeItem(key);
        }
      }
      async migrate() {
        var _a;
        const migrated = [];
        const existing = [];
        const oldprefix = "_cap_";
        const keys = Object.keys(this.impl).filter((k) => k.indexOf(oldprefix) === 0);
        for (const oldkey of keys) {
          const key = oldkey.substring(oldprefix.length);
          const value = (_a = this.impl.getItem(oldkey)) !== null && _a !== void 0 ? _a : "";
          const { value: currentValue } = await this.get({ key });
          if (typeof currentValue === "string") {
            existing.push(key);
          } else {
            await this.set({ key, value });
            migrated.push(key);
          }
        }
        return { migrated, existing };
      }
      async removeOld() {
        const oldprefix = "_cap_";
        const keys = Object.keys(this.impl).filter((k) => k.indexOf(oldprefix) === 0);
        for (const oldkey of keys) {
          this.impl.removeItem(oldkey);
        }
      }
      get impl() {
        return window.localStorage;
      }
      get prefix() {
        return this.group === "NativeStorage" ? "" : `${this.group}.`;
      }
      rawKeys() {
        return Object.keys(this.impl).filter((k) => k.indexOf(this.prefix) === 0);
      }
      applyPrefix(key) {
        return this.prefix + key;
      }
    };
  }
});

// node_modules/@capacitor/filesystem/dist/esm/definitions.js
var Directory, Encoding;
var init_definitions = __esm({
  "node_modules/@capacitor/filesystem/dist/esm/definitions.js"() {
    (function(Directory2) {
      Directory2["Documents"] = "DOCUMENTS";
      Directory2["Data"] = "DATA";
      Directory2["Library"] = "LIBRARY";
      Directory2["Cache"] = "CACHE";
      Directory2["External"] = "EXTERNAL";
      Directory2["ExternalStorage"] = "EXTERNAL_STORAGE";
      Directory2["ExternalCache"] = "EXTERNAL_CACHE";
      Directory2["LibraryNoCloud"] = "LIBRARY_NO_CLOUD";
      Directory2["Temporary"] = "TEMPORARY";
    })(Directory || (Directory = {}));
    (function(Encoding2) {
      Encoding2["UTF8"] = "utf8";
      Encoding2["ASCII"] = "ascii";
      Encoding2["UTF16"] = "utf16";
    })(Encoding || (Encoding = {}));
  }
});

// node_modules/@capacitor/filesystem/dist/esm/web.js
var web_exports2 = {};
__export(web_exports2, {
  FilesystemWeb: () => FilesystemWeb
});
function resolve(path) {
  const posix = path.split("/").filter((item) => item !== ".");
  const newPosix = [];
  posix.forEach((item) => {
    if (item === ".." && newPosix.length > 0 && newPosix[newPosix.length - 1] !== "..") {
      newPosix.pop();
    } else {
      newPosix.push(item);
    }
  });
  return newPosix.join("/");
}
function isPathParent(parent, children) {
  parent = resolve(parent);
  children = resolve(children);
  const pathsA = parent.split("/");
  const pathsB = children.split("/");
  return parent !== children && pathsA.every((value, index) => value === pathsB[index]);
}
var FilesystemWeb;
var init_web2 = __esm({
  "node_modules/@capacitor/filesystem/dist/esm/web.js"() {
    init_dist();
    init_definitions();
    FilesystemWeb = class _FilesystemWeb extends WebPlugin {
      constructor() {
        super(...arguments);
        this.DB_VERSION = 1;
        this.DB_NAME = "Disc";
        this._writeCmds = ["add", "put", "delete"];
        this.downloadFile = async (options) => {
          var _a, _b;
          const requestInit = buildRequestInit(options, options.webFetchExtra);
          const response = await fetch(options.url, requestInit);
          let blob;
          if (!options.progress)
            blob = await response.blob();
          else if (!(response === null || response === void 0 ? void 0 : response.body))
            blob = new Blob();
          else {
            const reader = response.body.getReader();
            let bytes = 0;
            const chunks = [];
            const contentType = response.headers.get("content-type");
            const contentLength = parseInt(response.headers.get("content-length") || "0", 10);
            while (true) {
              const { done, value } = await reader.read();
              if (done)
                break;
              chunks.push(value);
              bytes += (value === null || value === void 0 ? void 0 : value.length) || 0;
              const status = {
                url: options.url,
                bytes,
                contentLength
              };
              this.notifyListeners("progress", status);
            }
            const allChunks = new Uint8Array(bytes);
            let position = 0;
            for (const chunk of chunks) {
              if (typeof chunk === "undefined")
                continue;
              allChunks.set(chunk, position);
              position += chunk.length;
            }
            blob = new Blob([allChunks.buffer], { type: contentType || void 0 });
          }
          const result = await this.writeFile({
            path: options.path,
            directory: (_a = options.directory) !== null && _a !== void 0 ? _a : void 0,
            recursive: (_b = options.recursive) !== null && _b !== void 0 ? _b : false,
            data: blob
          });
          return { path: result.uri, blob };
        };
      }
      readFileInChunks(_options, _callback) {
        throw this.unavailable("Method not implemented.");
      }
      async initDb() {
        if (this._db !== void 0) {
          return this._db;
        }
        if (!("indexedDB" in window)) {
          throw this.unavailable("This browser doesn't support IndexedDB");
        }
        return new Promise((resolve2, reject) => {
          const request = indexedDB.open(this.DB_NAME, this.DB_VERSION);
          request.onupgradeneeded = _FilesystemWeb.doUpgrade;
          request.onsuccess = () => {
            this._db = request.result;
            resolve2(request.result);
          };
          request.onerror = () => reject(request.error);
          request.onblocked = () => {
            console.warn("db blocked");
          };
        });
      }
      static doUpgrade(event) {
        const eventTarget = event.target;
        const db = eventTarget.result;
        switch (event.oldVersion) {
          case 0:
          case 1:
          default: {
            if (db.objectStoreNames.contains("FileStorage")) {
              db.deleteObjectStore("FileStorage");
            }
            const store = db.createObjectStore("FileStorage", { keyPath: "path" });
            store.createIndex("by_folder", "folder");
          }
        }
      }
      async dbRequest(cmd, args) {
        const readFlag = this._writeCmds.indexOf(cmd) !== -1 ? "readwrite" : "readonly";
        return this.initDb().then((conn) => {
          return new Promise((resolve2, reject) => {
            const tx = conn.transaction(["FileStorage"], readFlag);
            const store = tx.objectStore("FileStorage");
            const req = store[cmd](...args);
            req.onsuccess = () => resolve2(req.result);
            req.onerror = () => reject(req.error);
          });
        });
      }
      async dbIndexRequest(indexName, cmd, args) {
        const readFlag = this._writeCmds.indexOf(cmd) !== -1 ? "readwrite" : "readonly";
        return this.initDb().then((conn) => {
          return new Promise((resolve2, reject) => {
            const tx = conn.transaction(["FileStorage"], readFlag);
            const store = tx.objectStore("FileStorage");
            const index = store.index(indexName);
            const req = index[cmd](...args);
            req.onsuccess = () => resolve2(req.result);
            req.onerror = () => reject(req.error);
          });
        });
      }
      getPath(directory, uriPath) {
        const cleanedUriPath = uriPath !== void 0 ? uriPath.replace(/^[/]+|[/]+$/g, "") : "";
        let fsPath = "";
        if (directory !== void 0)
          fsPath += "/" + directory;
        if (uriPath !== "")
          fsPath += "/" + cleanedUriPath;
        return fsPath;
      }
      async clear() {
        const conn = await this.initDb();
        const tx = conn.transaction(["FileStorage"], "readwrite");
        const store = tx.objectStore("FileStorage");
        store.clear();
      }
      /**
       * Read a file from disk
       * @param options options for the file read
       * @return a promise that resolves with the read file data result
       */
      async readFile(options) {
        const path = this.getPath(options.directory, options.path);
        const entry = await this.dbRequest("get", [path]);
        if (entry === void 0)
          throw Error("File does not exist.");
        return { data: entry.content ? entry.content : "" };
      }
      /**
       * Write a file to disk in the specified location on device
       * @param options options for the file write
       * @return a promise that resolves with the file write result
       */
      async writeFile(options) {
        const path = this.getPath(options.directory, options.path);
        let data2 = options.data;
        const encoding = options.encoding;
        const doRecursive = options.recursive;
        const occupiedEntry = await this.dbRequest("get", [path]);
        if (occupiedEntry && occupiedEntry.type === "directory")
          throw Error("The supplied path is a directory.");
        const parentPath = path.substr(0, path.lastIndexOf("/"));
        const parentEntry = await this.dbRequest("get", [parentPath]);
        if (parentEntry === void 0) {
          const subDirIndex = parentPath.indexOf("/", 1);
          if (subDirIndex !== -1) {
            const parentArgPath = parentPath.substr(subDirIndex);
            await this.mkdir({
              path: parentArgPath,
              directory: options.directory,
              recursive: doRecursive
            });
          }
        }
        if (!encoding && !(data2 instanceof Blob)) {
          data2 = data2.indexOf(",") >= 0 ? data2.split(",")[1] : data2;
          if (!this.isBase64String(data2))
            throw Error("The supplied data is not valid base64 content.");
        }
        const now = Date.now();
        const pathObj = {
          path,
          folder: parentPath,
          type: "file",
          size: data2 instanceof Blob ? data2.size : data2.length,
          ctime: now,
          mtime: now,
          content: data2
        };
        await this.dbRequest("put", [pathObj]);
        return {
          uri: pathObj.path
        };
      }
      /**
       * Append to a file on disk in the specified location on device
       * @param options options for the file append
       * @return a promise that resolves with the file write result
       */
      async appendFile(options) {
        const path = this.getPath(options.directory, options.path);
        let data2 = options.data;
        const encoding = options.encoding;
        const parentPath = path.substr(0, path.lastIndexOf("/"));
        const now = Date.now();
        let ctime = now;
        const occupiedEntry = await this.dbRequest("get", [path]);
        if (occupiedEntry && occupiedEntry.type === "directory")
          throw Error("The supplied path is a directory.");
        const parentEntry = await this.dbRequest("get", [parentPath]);
        if (parentEntry === void 0) {
          const subDirIndex = parentPath.indexOf("/", 1);
          if (subDirIndex !== -1) {
            const parentArgPath = parentPath.substr(subDirIndex);
            await this.mkdir({
              path: parentArgPath,
              directory: options.directory,
              recursive: true
            });
          }
        }
        if (!encoding && !this.isBase64String(data2))
          throw Error("The supplied data is not valid base64 content.");
        if (occupiedEntry !== void 0) {
          if (occupiedEntry.content instanceof Blob) {
            throw Error("The occupied entry contains a Blob object which cannot be appended to.");
          }
          if (occupiedEntry.content !== void 0 && !encoding) {
            data2 = btoa(atob(occupiedEntry.content) + atob(data2));
          } else {
            data2 = occupiedEntry.content + data2;
          }
          ctime = occupiedEntry.ctime;
        }
        const pathObj = {
          path,
          folder: parentPath,
          type: "file",
          size: data2.length,
          ctime,
          mtime: now,
          content: data2
        };
        await this.dbRequest("put", [pathObj]);
      }
      /**
       * Delete a file from disk
       * @param options options for the file delete
       * @return a promise that resolves with the deleted file data result
       */
      async deleteFile(options) {
        const path = this.getPath(options.directory, options.path);
        const entry = await this.dbRequest("get", [path]);
        if (entry === void 0)
          throw Error("File does not exist.");
        const entries = await this.dbIndexRequest("by_folder", "getAllKeys", [IDBKeyRange.only(path)]);
        if (entries.length !== 0)
          throw Error("Folder is not empty.");
        await this.dbRequest("delete", [path]);
      }
      /**
       * Create a directory.
       * @param options options for the mkdir
       * @return a promise that resolves with the mkdir result
       */
      async mkdir(options) {
        const path = this.getPath(options.directory, options.path);
        const doRecursive = options.recursive;
        const parentPath = path.substr(0, path.lastIndexOf("/"));
        const depth = (path.match(/\//g) || []).length;
        const parentEntry = await this.dbRequest("get", [parentPath]);
        const occupiedEntry = await this.dbRequest("get", [path]);
        if (depth === 1)
          throw Error("Cannot create Root directory");
        if (occupiedEntry !== void 0)
          throw Error("Current directory does already exist.");
        if (!doRecursive && depth !== 2 && parentEntry === void 0)
          throw Error("Parent directory must exist");
        if (doRecursive && depth !== 2 && parentEntry === void 0) {
          const parentArgPath = parentPath.substr(parentPath.indexOf("/", 1));
          await this.mkdir({
            path: parentArgPath,
            directory: options.directory,
            recursive: doRecursive
          });
        }
        const now = Date.now();
        const pathObj = {
          path,
          folder: parentPath,
          type: "directory",
          size: 0,
          ctime: now,
          mtime: now
        };
        await this.dbRequest("put", [pathObj]);
      }
      /**
       * Remove a directory
       * @param options the options for the directory remove
       */
      async rmdir(options) {
        const { path, directory, recursive } = options;
        const fullPath = this.getPath(directory, path);
        const entry = await this.dbRequest("get", [fullPath]);
        if (entry === void 0)
          throw Error("Folder does not exist.");
        if (entry.type !== "directory")
          throw Error("Requested path is not a directory");
        const readDirResult = await this.readdir({ path, directory });
        if (readDirResult.files.length !== 0 && !recursive)
          throw Error("Folder is not empty");
        for (const entry2 of readDirResult.files) {
          const entryPath = `${path}/${entry2.name}`;
          const entryObj = await this.stat({ path: entryPath, directory });
          if (entryObj.type === "file") {
            await this.deleteFile({ path: entryPath, directory });
          } else {
            await this.rmdir({ path: entryPath, directory, recursive });
          }
        }
        await this.dbRequest("delete", [fullPath]);
      }
      /**
       * Return a list of files from the directory (not recursive)
       * @param options the options for the readdir operation
       * @return a promise that resolves with the readdir directory listing result
       */
      async readdir(options) {
        const path = this.getPath(options.directory, options.path);
        const entry = await this.dbRequest("get", [path]);
        if (options.path !== "" && entry === void 0)
          throw Error("Folder does not exist.");
        const entries = await this.dbIndexRequest("by_folder", "getAllKeys", [IDBKeyRange.only(path)]);
        const files = await Promise.all(entries.map(async (e) => {
          let subEntry = await this.dbRequest("get", [e]);
          if (subEntry === void 0) {
            subEntry = await this.dbRequest("get", [e + "/"]);
          }
          return {
            name: e.substring(path.length + 1),
            type: subEntry.type,
            size: subEntry.size,
            ctime: subEntry.ctime,
            mtime: subEntry.mtime,
            uri: subEntry.path
          };
        }));
        return { files };
      }
      /**
       * Return full File URI for a path and directory
       * @param options the options for the stat operation
       * @return a promise that resolves with the file stat result
       */
      async getUri(options) {
        const path = this.getPath(options.directory, options.path);
        let entry = await this.dbRequest("get", [path]);
        if (entry === void 0) {
          entry = await this.dbRequest("get", [path + "/"]);
        }
        return {
          uri: (entry === null || entry === void 0 ? void 0 : entry.path) || path
        };
      }
      /**
       * Return data about a file
       * @param options the options for the stat operation
       * @return a promise that resolves with the file stat result
       */
      async stat(options) {
        const path = this.getPath(options.directory, options.path);
        let entry = await this.dbRequest("get", [path]);
        if (entry === void 0) {
          entry = await this.dbRequest("get", [path + "/"]);
        }
        if (entry === void 0)
          throw Error("Entry does not exist.");
        return {
          name: entry.path.substring(path.length + 1),
          type: entry.type,
          size: entry.size,
          ctime: entry.ctime,
          mtime: entry.mtime,
          uri: entry.path
        };
      }
      /**
       * Rename a file or directory
       * @param options the options for the rename operation
       * @return a promise that resolves with the rename result
       */
      async rename(options) {
        await this._copy(options, true);
        return;
      }
      /**
       * Copy a file or directory
       * @param options the options for the copy operation
       * @return a promise that resolves with the copy result
       */
      async copy(options) {
        return this._copy(options, false);
      }
      async requestPermissions() {
        return { publicStorage: "granted" };
      }
      async checkPermissions() {
        return { publicStorage: "granted" };
      }
      /**
       * Function that can perform a copy or a rename
       * @param options the options for the rename operation
       * @param doRename whether to perform a rename or copy operation
       * @return a promise that resolves with the result
       */
      async _copy(options, doRename = false) {
        let { toDirectory } = options;
        const { to, from, directory: fromDirectory } = options;
        if (!to || !from) {
          throw Error("Both to and from must be provided");
        }
        if (!toDirectory) {
          toDirectory = fromDirectory;
        }
        const fromPath = this.getPath(fromDirectory, from);
        const toPath = this.getPath(toDirectory, to);
        if (fromPath === toPath) {
          return {
            uri: toPath
          };
        }
        if (isPathParent(fromPath, toPath)) {
          throw Error("To path cannot contain the from path");
        }
        let toObj;
        try {
          toObj = await this.stat({
            path: to,
            directory: toDirectory
          });
        } catch (e) {
          const toPathComponents = to.split("/");
          toPathComponents.pop();
          const toPath2 = toPathComponents.join("/");
          if (toPathComponents.length > 0) {
            const toParentDirectory = await this.stat({
              path: toPath2,
              directory: toDirectory
            });
            if (toParentDirectory.type !== "directory") {
              throw new Error("Parent directory of the to path is a file");
            }
          }
        }
        if (toObj && toObj.type === "directory") {
          throw new Error("Cannot overwrite a directory with a file");
        }
        const fromObj = await this.stat({
          path: from,
          directory: fromDirectory
        });
        const updateTime = async (path, ctime2, mtime) => {
          const fullPath = this.getPath(toDirectory, path);
          const entry = await this.dbRequest("get", [fullPath]);
          entry.ctime = ctime2;
          entry.mtime = mtime;
          await this.dbRequest("put", [entry]);
        };
        const ctime = fromObj.ctime ? fromObj.ctime : Date.now();
        switch (fromObj.type) {
          // The "from" object is a file
          case "file": {
            const file = await this.readFile({
              path: from,
              directory: fromDirectory
            });
            if (doRename) {
              await this.deleteFile({
                path: from,
                directory: fromDirectory
              });
            }
            let encoding;
            if (!(file.data instanceof Blob) && !this.isBase64String(file.data)) {
              encoding = Encoding.UTF8;
            }
            const writeResult = await this.writeFile({
              path: to,
              directory: toDirectory,
              data: file.data,
              encoding
            });
            if (doRename) {
              await updateTime(to, ctime, fromObj.mtime);
            }
            return writeResult;
          }
          case "directory": {
            if (toObj) {
              throw Error("Cannot move a directory over an existing object");
            }
            try {
              await this.mkdir({
                path: to,
                directory: toDirectory,
                recursive: false
              });
              if (doRename) {
                await updateTime(to, ctime, fromObj.mtime);
              }
            } catch (e) {
            }
            const contents = (await this.readdir({
              path: from,
              directory: fromDirectory
            })).files;
            for (const filename of contents) {
              await this._copy({
                from: `${from}/${filename.name}`,
                to: `${to}/${filename.name}`,
                directory: fromDirectory,
                toDirectory
              }, doRename);
            }
            if (doRename) {
              await this.rmdir({
                path: from,
                directory: fromDirectory
              });
            }
          }
        }
        return {
          uri: toPath
        };
      }
      isBase64String(str) {
        try {
          return btoa(atob(str)) == str;
        } catch (err) {
          return false;
        }
      }
    };
    FilesystemWeb._debug = true;
  }
});

// node_modules/@capacitor/share/dist/esm/web.js
var web_exports3 = {};
__export(web_exports3, {
  ShareWeb: () => ShareWeb
});
var ShareWeb;
var init_web3 = __esm({
  "node_modules/@capacitor/share/dist/esm/web.js"() {
    init_dist();
    ShareWeb = class extends WebPlugin {
      async canShare() {
        if (typeof navigator === "undefined" || !navigator.share) {
          return { value: false };
        } else {
          return { value: true };
        }
      }
      async share(options) {
        if (typeof navigator === "undefined" || !navigator.share) {
          throw this.unavailable("Share API not available in this browser");
        }
        await navigator.share({
          title: options.title,
          text: options.text,
          url: options.url
        });
        return {};
      }
    };
  }
});

// public/storage.js
init_dist();

// node_modules/@capacitor/preferences/dist/esm/index.js
init_dist();
var Preferences = registerPlugin("Preferences", {
  web: () => Promise.resolve().then(() => (init_web(), web_exports)).then((m) => new m.PreferencesWeb())
});

// public/core.js
var CURRENCIES = ["CNY", "USD"];
function validDate(s2) {
  if (typeof s2 !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(s2)) return false;
  const d = /* @__PURE__ */ new Date(s2 + "T12:00:00Z");
  return s2 >= "1900-01-01" && s2 <= "2200-12-31" && !Number.isNaN(+d) && d.toISOString().slice(0, 10) === s2;
}
function addDays(s2, n) {
  const d = /* @__PURE__ */ new Date(s2 + "T12:00:00Z");
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
}
function shiftMonths(s2, n) {
  const [y, m, day2] = s2.split("-").map(Number);
  const d = new Date(Date.UTC(y, m - 1 + n, 1, 12));
  const last = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 1, 0, 12)).getUTCDate();
  d.setUTCDate(Math.min(day2, last));
  return d.toISOString().slice(0, 10);
}
function boundary(s2, n) {
  if (s2.cycle === "monthly") return shiftMonths(s2.dueDate, n);
  if (s2.cycle === "yearly") return shiftMonths(s2.dueDate, n * 12);
  if (s2.cycle === "custom") return addDays(s2.dueDate, n * s2.customDays);
  return n === 0 ? s2.dueDate : null;
}
function nextBoundary(s2, date) {
  if (s2.cycle === "once") return null;
  for (let n = 0; n <= 11e4; n++) {
    const d = boundary(s2, n);
    if (d > date) return d;
  }
  return null;
}
function validateSubscription(input) {
  const s2 = {
    id: input.id,
    name: String(input.name || "").trim(),
    account: String(input.account || "").trim(),
    description: String(input.description || "").trim(),
    notes: String(input.notes || "").trim(),
    startDate: input.startDate || "",
    dueDate: input.dueDate,
    dueType: input.dueType || "charge",
    amount: Number(input.amount),
    currency: input.currency || "CNY",
    cycle: input.cycle || "monthly",
    customDays: Number(input.customDays ?? 30),
    autoRenew: input.autoRenew === true,
    category: input.category || "\u5176\u4ED6",
    status: input.status || "active",
    trialEnd: input.trialEnd || "",
    reminders: Array.isArray(input.reminders) ? [...new Set(input.reminders)].sort((a, b) => b - a) : [7, 3, 1]
  };
  if (!s2.name || s2.name.length > 100) throw Error("\u670D\u52A1\u540D\u79F0\u5FC5\u586B\uFF0C\u6700\u591A 100 \u4E2A\u5B57");
  if (!validDate(s2.dueDate) || s2.startDate && !validDate(s2.startDate) || s2.trialEnd && !validDate(s2.trialEnd)) throw Error("\u8BF7\u586B\u5199\u6709\u6548\u65E5\u671F\uFF081900\u20142200 \u5E74\uFF09");
  if (s2.startDate && s2.startDate > s2.dueDate) throw Error("\u5F00\u59CB\u65E5\u671F\u4E0D\u80FD\u665A\u4E8E\u5230\u671F/\u6263\u6B3E\u65E5\u671F");
  if (!Number.isFinite(s2.amount) || s2.amount < 0 || s2.amount > 1e8 || Math.abs(s2.amount * 100 - Math.round(s2.amount * 100)) > 1e-5) throw Error("\u91D1\u989D\u9700\u4E3A\u975E\u8D1F\u6570\uFF0C\u6700\u591A\u4E24\u4F4D\u5C0F\u6570");
  if (!CURRENCIES.includes(s2.currency)) throw Error("\u5E01\u79CD\u4E0D\u652F\u6301");
  if (!["monthly", "yearly", "custom", "once"].includes(s2.cycle) || !Number.isInteger(s2.customDays) || s2.customDays < 1 || s2.customDays > 3650) throw Error("\u5468\u671F\u4E0D\u6B63\u786E\uFF0C\u81EA\u5B9A\u4E49\u5468\u671F\u4E3A 1\u20143650 \u5929");
  if (!["charge", "expiry"].includes(s2.dueType) || !["active", "canceled", "expired"].includes(s2.status)) throw Error("\u72B6\u6001\u6216\u65E5\u671F\u7C7B\u578B\u4E0D\u6B63\u786E");
  if (!["AI", "\u97F3\u4E50", "\u4E91\u5B58\u50A8", "\u5B66\u4E60", "\u5176\u4ED6"].includes(s2.category)) throw Error("\u5206\u7C7B\u4E0D\u6B63\u786E");
  if ([s2.account, s2.description, s2.notes].some((v) => v.length > 3e3)) throw Error("\u5907\u6CE8\u6700\u591A 3000 \u4E2A\u5B57");
  if (s2.reminders.some((v) => !Number.isInteger(v) || v < 0 || v > 365)) throw Error("\u63D0\u9192\u5929\u6570\u9700\u4E3A 0\u2014365 \u7684\u6574\u6570");
  if (s2.status !== "active" || s2.cycle === "once") s2.autoRenew = false;
  return s2;
}
function eventsFor(subscriptions, payments, from, to) {
  const events = [];
  for (const s2 of subscriptions) {
    const paid = new Set(payments.filter((p) => p.subscriptionId === s2.id && p.scheduleId === s2.scheduleId).map((p) => p.dueDate));
    const repeats = s2.status === "active" && s2.autoRenew && s2.cycle !== "once";
    for (let n = 0; n < (repeats ? 11e4 : 1); n++) {
      const date = boundary(s2, n);
      if (!date || date > to) break;
      if (date >= from && !paid.has(date)) events.push({ id: `${s2.id}:${date}`, subscriptionId: s2.id, date, kind: repeats ? "expected" : "due", name: s2.name, amount: s2.amount, currency: s2.currency, s: s2 });
    }
    if (!repeats && s2.cycle !== "once") {
      const paidEnd = payments.filter((p) => p.subscriptionId === s2.id && p.scheduleId === s2.scheduleId).map((p) => p.periodEnd).filter(Boolean).sort().at(-1);
      if (paidEnd && paidEnd > s2.dueDate && paidEnd >= from && paidEnd <= to && !paid.has(paidEnd)) events.push({ id: `${s2.id}:${paidEnd}`, subscriptionId: s2.id, date: paidEnd, kind: "due", name: s2.name, amount: s2.amount, currency: s2.currency, s: s2 });
    }
    if (s2.trialEnd && s2.trialEnd >= from && s2.trialEnd <= to) events.push({ id: `${s2.id}:trial`, subscriptionId: s2.id, date: s2.trialEnd, kind: "trial", name: s2.name, amount: 0, currency: s2.currency, s: s2 });
  }
  for (const p of payments) if (p.paidDate >= from && p.paidDate <= to) events.push({ id: p.id, subscriptionId: p.subscriptionId, date: p.paidDate, kind: "paid", name: p.name, amount: p.amount, currency: p.currency, p });
  return events.sort((a, b) => a.date.localeCompare(b.date) || a.name.localeCompare(b.name));
}
function statistics(subs, payments, today2) {
  const first = today2.slice(0, 7) + "-01", last = addDays(shiftMonths(first, 1), -1), end30 = addDays(today2, 29);
  const yearEnd = addDays(shiftMonths(today2, 12), -1);
  const expected = eventsFor(subs, payments, today2, yearEnd).filter((e) => e.kind === "expected");
  const total = (xs) => Object.fromEntries(CURRENCIES.map((c) => [c, xs.filter((x) => x.currency === c).reduce((n, x) => n + Math.round(x.amount * 100), 0) / 100]));
  return { actual: total(payments.filter((p) => p.paidDate >= first && p.paidDate <= last)), remaining: total(expected.filter((e) => e.date <= last)), next30: total(expected.filter((e) => e.date <= end30)), annual: total(expected), active: subs.filter((s2) => s2.status === "active").length };
}
function icsText(s2) {
  return String(s2).replace(/\\/g, "\\\\").replace(/\r?\n/g, "\\n").replace(/;/g, "\\;").replace(/,/g, "\\,");
}
function fold(line) {
  const chunks = [];
  let part = "", bytes = 0;
  for (const c of line) {
    const size = new TextEncoder().encode(c).length;
    if (bytes + size > 73) {
      chunks.push(part);
      part = " ";
      bytes = 1;
    }
    part += c;
    bytes += size;
  }
  chunks.push(part);
  return chunks.join("\r\n");
}
function makeICS(subs, payments, from, to) {
  const stamp = (/* @__PURE__ */ new Date()).toISOString().replace(/[-:]/g, "").replace(/\.\d{3}/, "");
  const lines = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//PhyCalendar//Personal Calendar//ZH", "CALSCALE:GREGORIAN", "METHOD:PUBLISH", "X-WR-CALNAME:\u4E2A\u4EBA\u8BA2\u9605\u65E5\u5386\uFF08\u9759\u6001\u5907\u4EFD\uFF09"];
  for (const e of eventsFor(subs, payments, from, to).filter((e2) => e2.kind !== "paid")) {
    lines.push("BEGIN:VEVENT", `UID:${icsText(e.id)}@phycalendar.local`, `DTSTAMP:${stamp}`, `DTSTART;VALUE=DATE:${e.date.replaceAll("-", "")}`, `DTEND;VALUE=DATE:${addDays(e.date, 1).replaceAll("-", "")}`, `SUMMARY:${icsText(`${e.kind === "expected" ? "[\u9884\u8BA1] " : e.kind === "trial" ? "[\u8BD5\u7528\u7ED3\u675F] " : "[\u5230\u671F] "}${e.name}`)}`, `DESCRIPTION:${icsText(`${e.currency} ${e.amount.toFixed(2)}\uFF1B\u9759\u6001\u5BFC\u51FA\uFF0C\u4E0D\u8868\u793A\u5DF2\u4ED8\u6B3E\u3002\u8BF7\u4EE5\u5E94\u7528\u5185\u8BB0\u5F55\u4E3A\u51C6\u3002`)}`);
    for (const days of e.s.reminders) lines.push("BEGIN:VALARM", "ACTION:DISPLAY", "DESCRIPTION:\u8BA2\u9605\u63D0\u9192", `TRIGGER:-P${days}D`, "END:VALARM");
    lines.push("END:VEVENT");
  }
  return lines.concat("END:VCALENDAR").map(fold).join("\r\n") + "\r\n";
}

// public/model.js
function validId(x) {
  return typeof x === "string" && /^[a-zA-Z0-9-]{1,80}$/.test(x);
}
function validateBackup(b) {
  if (![1, 2].includes(b.version) || !Array.isArray(b.subscriptions) || !Array.isArray(b.payments) || b.subscriptions.length > 2e3 || b.payments.length > 5e4) throw Error("\u5907\u4EFD\u683C\u5F0F\u65E0\u6548\u6216\u8BB0\u5F55\u8FC7\u591A");
  const ids = /* @__PURE__ */ new Set(), pids = /* @__PURE__ */ new Set();
  const subscriptions = b.subscriptions.map((x) => {
    if (!validId(x.id) || !validId(x.scheduleId) || ids.has(x.id)) throw Error("\u8BA2\u9605\u7F16\u53F7\u65E0\u6548\u6216\u91CD\u590D");
    ids.add(x.id);
    return { ...validateSubscription(x), scheduleId: x.scheduleId };
  });
  const keys = /* @__PURE__ */ new Set();
  const payments = b.payments.map((p) => {
    if (!validId(p.id) || pids.has(p.id) || !validId(p.subscriptionId) || !validId(p.scheduleId) || !validDate(p.dueDate) || !validDate(p.paidDate) || !validDate(p.periodStart) || !validDate(p.periodEnd) || p.periodEnd < p.periodStart || !["CNY", "USD"].includes(p.currency) || typeof p.name !== "string" || !p.name.trim() || p.name.length > 100 || typeof p.amount !== "number" || !Number.isFinite(p.amount) || p.amount < 0 || p.amount > 1e8 || Math.abs(p.amount * 100 - Math.round(p.amount * 100)) > 1e-5) throw Error("\u4ED8\u6B3E\u8BB0\u5F55\u683C\u5F0F\u65E0\u6548");
    const key = `${p.subscriptionId}:${p.scheduleId}:${p.dueDate}`;
    if (keys.has(key)) throw Error("\u5907\u4EFD\u5305\u542B\u91CD\u590D\u5468\u671F\u4ED8\u6B3E");
    keys.add(key);
    pids.add(p.id);
    return { id: p.id, subscriptionId: p.subscriptionId, scheduleId: p.scheduleId, name: p.name, dueDate: p.dueDate, paidDate: p.paidDate, periodStart: p.periodStart, periodEnd: p.periodEnd, amount: p.amount, currency: p.currency };
  });
  return { subscriptions, payments };
}
var SCHEMA_VERSION = 2;
function migrate(input) {
  if (!input || ![1, 2].includes(input.version)) throw Error("\u6570\u636E\u683C\u5F0F\u6765\u81EA\u66F4\u65B0\u7248\u672C\u6216\u683C\u5F0F\u635F\u574F\u3002\u539F\u6570\u636E\u672A\u6539\u52A8\uFF0C\u8BF7\u66F4\u65B0\u5E94\u7528\u6216\u6062\u590D JSON \u5907\u4EFD\u3002");
  const valid = validateBackup(input);
  return { ...valid, version: SCHEMA_VERSION, revision: Number.isSafeInteger(input.revision) && input.revision >= 0 ? input.revision : 0 };
}
var emptyState = () => ({ version: SCHEMA_VERSION, revision: 0, subscriptions: [], payments: [] });
function applyMutation(state, path, b, id = () => globalThis.crypto.randomUUID()) {
  state = migrate(structuredClone(state));
  if (b.revision !== state.revision) throw Error("\u53E6\u4E00\u4E2A\u7A97\u53E3\u5DF2\u4FEE\u6539\u6570\u636E\u3002\u8BF7\u5173\u95ED\u7F16\u8F91\u7A97\u53E3\u5E76\u5237\u65B0\u540E\u91CD\u8BD5\uFF0C\u907F\u514D\u8986\u76D6\u3002");
  if (path === "subscriptions") {
    const s2 = validateSubscription(b.subscription), old = state.subscriptions.find((x) => x.id === s2.id);
    if (s2.id && !old) throw Error("\u8BA2\u9605\u4E0D\u5B58\u5728");
    const changed = old && (old.dueDate !== s2.dueDate || old.cycle !== s2.cycle || s2.cycle === "custom" && old.customDays !== s2.customDays);
    const item = { ...s2, id: old?.id || id(), scheduleId: !old || changed ? id() : old.scheduleId };
    if (old) state.subscriptions = state.subscriptions.map((x) => x.id === item.id ? item : x);
    else {
      if (state.subscriptions.length >= 2e3) throw Error("\u6700\u591A 2000 \u4E2A\u8BA2\u9605");
      state.subscriptions.push(item);
    }
  } else if (path === "subscriptions/delete") state.subscriptions = state.subscriptions.filter((s2) => s2.id !== b.id);
  else if (path === "payments") {
    const s2 = state.subscriptions.find((s3) => s3.id === b.subscriptionId);
    if (!s2) throw Error("\u8BA2\u9605\u4E0D\u5B58\u5728");
    if (!validDate(b.dueDate) || !validDate(b.paidDate) || !Number.isFinite(b.amount) || b.amount < 0 || b.amount > 1e8 || Math.abs(b.amount * 100 - Math.round(b.amount * 100)) > 1e-5) throw Error("\u4ED8\u6B3E\u65E5\u671F\u6216\u91D1\u989D\u65E0\u6548");
    if (b.dueDate < s2.dueDate || (s2.cycle === "once" ? b.dueDate !== s2.dueDate : nextBoundary(s2, addDays(b.dueDate, -1)) !== b.dueDate)) throw Error("\u8BF7\u9009\u62E9\u8BA1\u5212\u4E2D\u7684\u5468\u671F\u65E5\u671F");
    if (state.payments.some((p) => p.subscriptionId === s2.id && p.scheduleId === s2.scheduleId && p.dueDate === b.dueDate)) throw Error("\u6B64\u5468\u671F\u5DF2\u786E\u8BA4\u4ED8\u6B3E");
    if (state.payments.length >= 5e4) throw Error("\u6700\u591A 50000 \u6761\u4ED8\u6B3E\u8BB0\u5F55");
    state.payments.push({ id: id(), subscriptionId: s2.id, scheduleId: s2.scheduleId, name: s2.name, dueDate: b.dueDate, paidDate: b.paidDate, amount: b.amount, currency: s2.currency, periodStart: b.dueDate, periodEnd: nextBoundary(s2, b.dueDate) || b.dueDate });
  } else if (path === "payments/delete") state.payments = state.payments.filter((p) => p.id !== b.id);
  else if (path === "import") {
    const imported = migrate(b.backup);
    state.subscriptions = imported.subscriptions;
    state.payments = imported.payments;
  } else throw Error("\u4E0D\u652F\u6301\u7684\u64CD\u4F5C");
  state.revision++;
  return state;
}

// public/storage.js
var native = Capacitor.isNativePlatform();
var KEY = "phycalendar-state";
var dbPromise;
var queue = Promise.resolve();
function openDB() {
  if (!dbPromise) dbPromise = new Promise((resolve2, reject) => {
    const req = indexedDB.open("phycalendar-local", 1);
    req.onupgradeneeded = () => {
      if (!req.result.objectStoreNames.contains("state")) req.result.createObjectStore("state");
    };
    req.onsuccess = () => {
      req.result.onversionchange = () => {
        req.result.close();
        dbPromise = null;
      };
      resolve2(req.result);
    };
    req.onerror = () => reject(Error("\u672C\u5730\u5B58\u50A8\u65E0\u6CD5\u6253\u5F00\u3002\u8BF7\u52FF\u4F7F\u7528\u65E0\u75D5\u6A21\u5F0F\uFF0C\u5E76\u68C0\u67E5\u78C1\u76D8\u7A7A\u95F4\u3002"));
    req.onblocked = () => reject(Error("\u8BF7\u5173\u95ED\u5176\u4ED6\u8BA2\u9605\u65E5\u5386\u7A97\u53E3\u540E\u91CD\u65B0\u6253\u5F00\u3002"));
  });
  return dbPromise;
}
async function browserTransaction(path, b) {
  const db = await openDB();
  return new Promise((resolve2, reject) => {
    const tx = db.transaction("state", path ? "readwrite" : "readonly"), store = tx.objectStore("state");
    let result, problem;
    tx.oncomplete = () => resolve2(result);
    tx.onabort = () => reject(problem || Error("\u672C\u5730\u5199\u5165\u5931\u8D25\uFF0C\u8BB0\u5F55\u672A\u4FDD\u5B58\u3002\u8BF7\u68C0\u67E5\u5269\u4F59\u7A7A\u95F4\uFF0C\u5BFC\u51FA\u5907\u4EFD\u540E\u518D\u8BD5\u3002"));
    tx.onerror = () => {
    };
    const req = store.get("current");
    req.onsuccess = () => {
      try {
        const previous = req.result, state = previous ? migrate(previous) : emptyState();
        if (path) {
          result = applyMutation(state, path, b);
          if (previous) store.put(previous, "previous");
          store.put(result, "current");
        } else result = state;
      } catch (e) {
        problem = e;
        tx.abort();
      }
    };
  });
}
async function nativeTransaction(path, b) {
  const { value } = await Preferences.get({ key: KEY });
  const state = value ? migrate(JSON.parse(value)) : emptyState();
  if (!path) return state;
  const result = applyMutation(state, path, b);
  if (value) await Preferences.set({ key: KEY + "-previous", value });
  await Preferences.set({ key: KEY, value: JSON.stringify(result) });
  return result;
}
function localRequest(path, b) {
  const run = () => native ? nativeTransaction(path, b) : browserTransaction(path, b);
  if (path) {
    const result = queue.then(run);
    queue = result.catch(() => {
    });
    return result;
  }
  return queue.then(run);
}
async function requestPersistence() {
  if (!native && navigator.storage?.persist) try {
    return await navigator.storage.persist();
  } catch {
  }
  return false;
}

// public/app.js
init_dist();

// node_modules/@capacitor/filesystem/dist/esm/index.js
init_dist();

// node_modules/@capacitor/synapse/dist/synapse.mjs
function s(t) {
  t.CapacitorUtils.Synapse = new Proxy(
    {},
    {
      get(e, n) {
        return new Proxy({}, {
          get(w, o) {
            return (c, p, r) => {
              const i = t.Capacitor.Plugins[n];
              if (i === void 0) {
                r(new Error(`Capacitor plugin ${n} not found`));
                return;
              }
              if (typeof i[o] != "function") {
                r(new Error(`Method ${o} not found in Capacitor plugin ${n}`));
                return;
              }
              (async () => {
                try {
                  const a = await i[o](c);
                  p(a);
                } catch (a) {
                  r(a);
                }
              })();
            };
          }
        });
      }
    }
  );
}
function u(t) {
  t.CapacitorUtils.Synapse = new Proxy(
    {},
    {
      get(e, n) {
        return t.cordova.plugins[n];
      }
    }
  );
}
function f(t = false) {
  typeof window > "u" || (window.CapacitorUtils = window.CapacitorUtils || {}, window.Capacitor !== void 0 && !t ? s(window) : window.cordova !== void 0 && u(window));
}

// node_modules/@capacitor/filesystem/dist/esm/index.js
init_definitions();
var Filesystem = registerPlugin("Filesystem", {
  web: () => Promise.resolve().then(() => (init_web2(), web_exports2)).then((m) => new m.FilesystemWeb())
});
f();

// node_modules/@capacitor/share/dist/esm/index.js
init_dist();
var Share = registerPlugin("Share", {
  web: () => Promise.resolve().then(() => (init_web3(), web_exports3)).then((m) => new m.ShareWeb())
});

// public/app.js
var $ = (s2) => document.querySelector(s2);
var $$ = (s2) => [...document.querySelectorAll(s2)];
var esc = (s2) => String(s2 ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
var localToday = () => {
  const d = /* @__PURE__ */ new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
};
var today = localToday();
var month = today.slice(0, 7) + "-01";
var data = { subscriptions: [], payments: [], revision: 0 };
var tab = "calendar";
var chosenDay = today;
var pendingBackup = null;
var backedUpRevision = null;
var busy = false;
var statusNames = { active: "\u4F7F\u7528\u4E2D", canceled: "\u5DF2\u53D6\u6D88\u7EED\u8D39", expired: "\u5DF2\u5230\u671F" };
var cycleNames = { monthly: "\u6708\u4ED8", yearly: "\u5E74\u4ED8", custom: "\u81EA\u5B9A\u4E49", once: "\u4E00\u6B21\u6027" };
var kinds = { expected: "\u9884\u8BA1", paid: "\u5DF2\u4ED8", due: "\u5230\u671F", trial: "\u8BD5\u7528\u7ED3\u675F" };
var money = (n, c) => `${c === "USD" ? "US$" : "\xA5"}${Number(n).toLocaleString("zh-CN", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
var totals = (t) => ["CNY", "USD"].map((c) => `<div>${money(t[c], c)}<small>${c}</small></div>`).join("");
function toast(message) {
  $("#toast").textContent = message;
  $("#toast").hidden = false;
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => $("#toast").hidden = true, 4500);
}
async function api(path, body) {
  if (path === "data") return localRequest();
  if (path === "backup") return { ...await localRequest(), exportedAt: (/* @__PURE__ */ new Date()).toISOString() };
  return localRequest(path, body);
}
async function load() {
  data = await api("data");
  today = localToday();
  render();
  $("#sync-status").textContent = "\u4FDD\u5B58\u5728\u6B64\u8BBE\u5907";
}
function closeAll() {
  $$("dialog[open]").forEach((d) => d.close());
}
async function mutate(path, body) {
  if (busy) throw Error("\u6B63\u5728\u4FDD\u5B58\uFF0C\u8BF7\u7A0D\u5019");
  busy = true;
  try {
    data = await api(path, { ...body, revision: data.revision });
    render();
    return data;
  } finally {
    busy = false;
  }
}
function switchTab(value) {
  tab = value;
  $$("[data-tab]").forEach((b) => b.classList.toggle("selected", b.dataset.tab === tab));
  for (const t of ["calendar", "list", "history", "settings"]) $(`#${t}-view`).hidden = t !== tab;
  const names = { calendar: "\u8BA2\u9605\u65E5\u5386", list: "\u5168\u90E8\u8BA2\u9605", history: "\u4ED8\u6B3E\u8BB0\u5F55", settings: "\u5907\u4EFD\u4E0E\u4F7F\u7528" };
  $("#page-name").textContent = names[tab];
  $("#view-heading").textContent = { calendar: "\u4F60\u7684\u8BA2\u9605\uFF0C\u4E00\u76EE\u4E86\u7136\u3002", list: "\u6BCF\u4E00\u4EFD\u8BA2\u9605\uFF0C\u90FD\u6709\u8BB0\u5F55\u3002", history: "\u628A\u5B9E\u9645\u82B1\u8D39\uFF0C\u8BB0\u5F97\u6E05\u695A\u3002", settings: "\u5B89\u5FC3\u8BB0\u5F55\uFF0C\u968F\u65F6\u5E26\u8D70\u3002" }[tab];
  render();
}
function eventHTML(e) {
  return `<button class="event ${e.kind}" data-detail="${esc(e.subscriptionId)}" data-date="${e.kind === "paid" ? "" : e.date}" title="${esc(e.name)} \xB7 ${kinds[e.kind]} ${money(e.amount, e.currency)}"><span class="event-name">${esc(e.name)}</span><span class="event-cost">${money(e.amount, e.currency)}</span><span class="event-kind">${kinds[e.kind]}</span></button>`;
}
function render() {
  $("#side-count").textContent = data.subscriptions.length;
  const st = statistics(data.subscriptions, data.payments, today);
  $("#stats").innerHTML = [["\u672C\u6708\u5B9E\u9645\u5DF2\u4ED8", st.actual, "\u6309\u5B9E\u9645\u4ED8\u6B3E\u65E5\u671F", "paid-stat"], ["\u672C\u6708\u5269\u4F59\u9884\u8BA1", st.remaining, "\u5C1A\u672A\u786E\u8BA4\u4ED8\u6B3E", ""], ["\u672A\u6765 30 \u5929\u9884\u8BA1", st.next30, "\u542B\u4ECA\u5929 \xB7 \u6309\u5F53\u524D\u4EF7\u683C", ""], ["\u5E74\u5EA6\u9884\u8BA1\u652F\u51FA", st.annual, "\u672A\u6765 12 \u4E2A\u6708 \xB7 \u672A\u4ED8\u6B3E", ""]].map(([title, value, note, cls]) => `<article class="stat ${cls}"><p>${title}<span>\u2197</span></p><strong>${totals(value)}</strong><small>${note}</small></article>`).join("") + `<article class="stat active-stat"><p>\u4F7F\u7528\u4E2D<span>\u25C9</span></p><strong>${st.active}<em>\u4E2A</em></strong><small>\u5171 ${data.subscriptions.length} \u4E2A\u8BA2\u9605</small></article>`;
  renderCalendar();
  renderList();
  renderPayments();
  renderUpcoming();
}
function renderCalendar() {
  const [y, m] = month.split("-").map(Number);
  $("#month-label").textContent = `${y} \u5E74 ${m} \u6708`;
  $("#month-caption").textContent = (/* @__PURE__ */ new Date(month + "T12:00:00Z")).toLocaleString("en", { month: "long", timeZone: "UTC" }).toUpperCase();
  $("#calendar-zone").textContent = `\u65E5\u671F\u6309\u672C\u673A\u65F6\u533A \xB7 ${Intl.DateTimeFormat().resolvedOptions().timeZone}`;
  const offset = ((/* @__PURE__ */ new Date(month + "T12:00:00Z")).getUTCDay() + 6) % 7, first = addDays(month, -offset), days = new Date(Date.UTC(y, m, 0)).getUTCDate(), count = Math.ceil((offset + days) / 7) * 7;
  const events = eventsFor(data.subscriptions, data.payments, first, addDays(first, count - 1));
  $("#calendar-grid").innerHTML = Array.from({ length: count }, (_, i) => {
    const d = addDays(first, i), items = events.filter((e) => e.date === d);
    return `<div class="day ${d.slice(0, 7) !== month.slice(0, 7) ? "outside" : ""} ${d === today ? "is-today" : ""}"><button class="day-number" data-day="${d}" aria-label="${d}\uFF0C${items.length} \u4E2A\u9879\u76EE"><span>${Number(d.slice(-2))}</span>${d === today ? "<small>\u4ECA\u5929</small>" : ""}${items.length ? `<i class="mobile-count">${items.length}</i>` : ""}</button><div class="day-items">${items.slice(0, 2).map(eventHTML).join("")}${items.length > 2 ? `<button class="more-events" data-day="${d}">\uFF0B${items.length - 2} \u9879 \xB7 \u67E5\u770B\u5168\u90E8</button>` : ""}</div></div>`;
  }).join("");
}
function empty(title, description) {
  return `<div class="empty"><div>\u25A6</div><h3>${title}</h3><p>${description}</p></div>`;
}
function nextEvent(s2) {
  return eventsFor([s2], data.payments, today, addDays(shiftMonths(today, 12), 1)).find((e) => e.kind !== "paid");
}
function subRow(s2) {
  const e = nextEvent(s2);
  return `<button class="subscription-row" data-detail="${esc(s2.id)}"><span class="service-icon category-${esc(s2.category)}">${esc(s2.name.slice(0, 1).toUpperCase())}</span><span class="row-main"><b>${esc(s2.name)}</b><small>${esc(s2.account || s2.category)} \xB7 ${cycleNames[s2.cycle]}${s2.cycle === "custom" ? ` / ${s2.customDays} \u5929` : ""}</small></span><span class="row-date">${e ? `${e.date}<small>${kinds[e.kind]}</small>` : "\u6682\u65E0\u672A\u6765\u8BA1\u5212"}</span><span class="row-amount">${money(s2.amount, s2.currency)}<small>${s2.currency}</small></span><span class="badge ${s2.status}">${statusNames[s2.status]}</span><span class="row-chevron">\u203A</span></button>`;
}
function renderList() {
  const q = $("#search").value.trim().toLowerCase(), category = $("#filter-category").value, status = $("#filter-status").value;
  const subs = data.subscriptions.filter((s2) => (!category || s2.category === category) && (!status || s2.status === status) && [s2.name, s2.account, s2.notes, s2.description].some((x) => x.toLowerCase().includes(q)));
  $("#subscription-list").innerHTML = subs.length ? subs.map(subRow).join("") : empty("\u8FD8\u6CA1\u6709\u5339\u914D\u7684\u8BA2\u9605", "\u4ECE\u53F3\u4E0A\u89D2\u65B0\u589E\u7B2C\u4E00\u4EFD\u771F\u5B9E\u8BA2\u9605\uFF0C\u6216\u8BD5\u7740\u8C03\u6574\u7B5B\u9009\u3002");
}
function renderPayments() {
  $("#payment-list").innerHTML = data.payments.length ? [...data.payments].sort((a, b) => b.paidDate.localeCompare(a.paidDate)).map((p) => `<div class="payment-row"><span class="service-icon">\u2713</span><span class="row-main"><b>${esc(p.name)}</b><small>${p.paidDate} \u5B9E\u9645\u4ED8\u6B3E \xB7 \u8BA1\u5212 ${p.dueDate}</small><small>\u5468\u671F ${p.periodStart} \u81F3 ${p.periodEnd}${p.periodStart !== p.periodEnd ? "\uFF08\u4E0D\u542B\u7ED3\u675F\u65E5\uFF09" : "\uFF08\u4E00\u6B21\u6027\uFF09"}</small></span><span class="row-amount">${money(p.amount, p.currency)}<small>${p.currency}</small></span><button class="text-button danger" data-undo="${p.id}">\u64A4\u9500</button></div>`).join("") : empty("\u4ED8\u6B3E\u5386\u53F2\u4ECE\u8FD9\u91CC\u5F00\u59CB", "\u9884\u8BA1\u6263\u6B3E\u4E0D\u4F1A\u7B97\u5165\u5B9E\u9645\u652F\u51FA\u3002\u4ED8\u6B3E\u540E\uFF0C\u5728\u8BA2\u9605\u8BE6\u60C5\u4E2D\u786E\u8BA4\u3002");
}
function renderUpcoming() {
  const to = addDays(today, 29), items = eventsFor(data.subscriptions, data.payments, today, to).filter((e) => e.kind !== "paid");
  const alerts = [];
  for (const s2 of data.subscriptions) {
    const next = nextEvent(s2);
    const overdue = eventsFor([s2], data.payments, s2.dueDate, addDays(today, -1)).filter((e) => e.kind !== "paid" && e.kind !== "trial");
    if (overdue.length) alerts.push(`<button class="alert-row" data-detail="${s2.id}" data-date="${overdue.at(-1).date}"><span class="alert-mark">!</span><span><b>${esc(s2.name)}</b><small>${s2.status === "expired" ? "\u5DF2\u6807\u8BB0\u5230\u671F" : "\u65E5\u671F\u5DF2\u8FC7\uFF0C\u5F85\u6838\u5B9E"} \xB7 ${overdue[0].date}${overdue.length > 1 ? ` \u8D77 ${overdue.length} \u4E2A\u5468\u671F` : ""} \xB7 \u4E0D\u4EE3\u8868\u5DF2\u6263\u6B3E</small></span><span>\u203A</span></button>`);
    if (s2.trialEnd && s2.trialEnd < today && s2.status === "active") alerts.push(`<button class="alert-row" data-detail="${s2.id}"><span class="alert-mark">!</span><span><b>${esc(s2.name)} \xB7 \u8BD5\u7528\u5DF2\u7ED3\u675F</b><small>${s2.trialEnd} \xB7 \u8BF7\u6838\u5B9E\u662F\u5426\u8F6C\u4ED8\u8D39\uFF0C\u5E76\u6E05\u9664\u8BD5\u7528\u65E5\u671F</small></span><span>\u203A</span></button>`);
    if (next && next.date >= today && s2.reminders.some((n) => addDays(today, n) === next.date)) alerts.push(`<button class="alert-row notice" data-detail="${s2.id}" data-date="${next.date}"><span class="alert-mark">\u25F7</span><span><b>${esc(s2.name)} \xB7 \u63D0\u524D\u63D0\u9192</b><small>${next.date} \xB7 ${kinds[next.kind]}</small></span><span>\u203A</span></button>`);
  }
  $("#upcoming").innerHTML = alerts.join("") + (items.length ? items.slice(0, 12).map((e) => `<button class="upcoming-row" data-detail="${e.subscriptionId}" data-date="${e.date}"><span class="date-tile"><small>${Number(e.date.slice(5, 7))} \u6708</small>${Number(e.date.slice(8))}</span><span class="row-main"><b>${esc(e.name)}</b><small>${kinds[e.kind]} \xB7 ${esc(e.s.category)}${e.s.trialEnd === e.date && e.kind === "expected" ? " \xB7 \u9884\u8BA1\u8F6C\u4ED8\u8D39" : ""}</small></span><span class="row-amount">${money(e.amount, e.currency)}<small>${e.currency}</small></span><span>\u203A</span></button>`).join("") + (items.length > 12 ? '<p class="form-hint">\u66F4\u591A\u9879\u76EE\u8BF7\u5728\u6708\u5386\u548C\u5168\u90E8\u8BA2\u9605\u4E2D\u67E5\u770B\u3002</p>' : "") : !alerts.length ? empty("\u6700\u8FD1\u6CA1\u6709\u5F85\u529E\uFF0C\u4EAB\u53D7\u8F7B\u677E\u65F6\u523B", "\u65B0\u589E\u8BA2\u9605\u540E\uFF0C\u8FD9\u91CC\u4F1A\u663E\u793A\u5230\u671F\u3001\u8BD5\u7528\u53CA\u7EED\u8D39\u63D0\u9192\u3002") : "");
}
function editor(s2 = null, date = today) {
  closeAll();
  const f2 = $("#subscription-form");
  f2.reset();
  $("#editor-title").textContent = s2 ? "\u7F16\u8F91\u8BA2\u9605" : "\u65B0\u589E\u8BA2\u9605";
  $("#editor-error").textContent = "";
  f2.elements.id.value = s2?.id || "";
  f2.elements.dueDate.value = date;
  $("#more-fields").open = false;
  if (s2) {
    for (const [k, v] of Object.entries(s2)) {
      const el = f2.elements.namedItem(k);
      if (el && k !== "reminders") el.type === "checkbox" ? el.checked = v : el.value = v;
    }
    $$('[name="reminder"]').forEach((el) => el.checked = s2.reminders.includes(Number(el.value)));
  }
  cycleChanged();
  $("#editor").showModal();
}
function cycleChanged() {
  const f2 = $("#subscription-form");
  $("#custom-days-label").hidden = f2.elements.cycle.value !== "custom";
  const disabled = f2.elements.cycle.value === "once" || f2.elements.status.value !== "active";
  f2.elements.autoRenew.disabled = disabled;
  if (disabled) f2.elements.autoRenew.checked = false;
}
function detail(id, date) {
  const s2 = data.subscriptions.find((s3) => s3.id === id);
  if (!s2) {
    toast("\u8BE5\u8BA2\u9605\u5DF2\u5220\u9664\uFF0C\u4ED8\u6B3E\u8BB0\u5F55\u4ECD\u4FDD\u7559\u5728\u5386\u53F2\u4E2D\u3002");
    return;
  }
  closeAll();
  const next = nextEvent(s2), due = date || next?.date || s2.dueDate;
  const records = data.payments.filter((p) => p.subscriptionId === id).sort((a, b) => b.paidDate.localeCompare(a.paidDate));
  $("#detail-content").innerHTML = `<div class="dialog-heading"><div class="service-title"><span class="service-icon">${esc(s2.name.slice(0, 1).toUpperCase())}</span><div><h2>${esc(s2.name)}</h2><span class="badge ${s2.status}">${statusNames[s2.status]}</span></div></div><button data-close="detail" class="icon-button" aria-label="\u5173\u95ED">\xD7</button></div><div class="detail-price">${money(s2.amount, s2.currency)} <small>${s2.currency} / ${cycleNames[s2.cycle]}${s2.cycle === "custom" ? ` ${s2.customDays} \u5929` : ""}</small></div><dl><dt>${s2.dueType === "charge" ? "\u539F\u59CB\u4E0B\u6B21\u6263\u6B3E\u65E5" : "\u539F\u59CB\u5F53\u524D\u5468\u671F\u5230\u671F\u65E5"}</dt><dd>${s2.dueDate}</dd><dt>\u672A\u6765\u6700\u8FD1\u9879\u76EE</dt><dd>${next ? `${next.date} \xB7 ${kinds[next.kind]}` : "\u6682\u65E0"}</dd><dt>\u81EA\u52A8\u7EED\u8D39</dt><dd>${s2.autoRenew ? "\u5F00\u542F \xB7 \u4EC5\u751F\u6210\u9884\u8BA1" : "\u5173\u95ED"}</dd><dt>\u5206\u7C7B / \u5F00\u59CB\u65E5\u671F</dt><dd>${esc(s2.category)} / ${s2.startDate || "\u672A\u586B\u5199"}</dd><dt>\u8D26\u53F7\u5907\u6CE8</dt><dd>${esc(s2.account || "\u672A\u586B\u5199")}</dd><dt>\u8BD5\u7528\u7ED3\u675F</dt><dd>${s2.trialEnd || "\u672A\u8BBE\u7F6E"}</dd><dt>\u63D0\u524D\u63D0\u9192</dt><dd>${s2.reminders.length ? s2.reminders.map((n) => `${n} \u5929`).join("\u3001") : "\u4E0D\u63D0\u9192"}</dd><dt>\u7B80\u4ECB</dt><dd class="preserve">${esc(s2.description || "\u2014")}</dd><dt>\u5907\u6CE8</dt><dd class="preserve">${esc(s2.notes || "\u2014")}</dd></dl><div class="button-row"><button class="primary" id="detail-pay">\u2713 \u786E\u8BA4\u5DF2\u4ED8\u6B3E</button><button class="outline" id="detail-edit">\u7F16\u8F91</button><button class="text-button danger" id="detail-delete">\u5220\u9664\u8BA2\u9605</button></div><h3>\u4ED8\u6B3E\u5386\u53F2 <small>(${records.length})</small></h3><div class="detail-history">${records.length ? records.map((p) => `<p>${p.paidDate} \xB7 ${money(p.amount, p.currency)}<small>\u8BA1\u5212 ${p.dueDate} \xB7 ${p.periodStart} \u2192 ${p.periodEnd}</small></p>`).join("") : '<p class="muted">\u6682\u65E0\u5B9E\u9645\u4ED8\u6B3E\u8BB0\u5F55\u3002</p>'}</div>`;
  $("#detail-edit").onclick = () => editor(s2);
  $("#detail-pay").onclick = () => payment(s2, due);
  $("#detail-delete").onclick = async () => {
    if (!confirm(`\u5220\u9664\u201C${s2.name}\u201D\uFF1F\u4ED8\u6B3E\u5386\u53F2\u5C06\u4FDD\u7559\uFF0C\u8BA2\u9605\u65E0\u6CD5\u5355\u72EC\u6062\u590D\u3002`)) return;
    try {
      await mutate("subscriptions/delete", { id });
      closeAll();
      toast("\u8BA2\u9605\u5DF2\u5220\u9664\uFF0C\u4ED8\u6B3E\u5386\u53F2\u5DF2\u4FDD\u7559");
    } catch (e) {
      toast(e.message);
    }
  };
  $("#detail").showModal();
}
function payment(s2, date) {
  closeAll();
  const f2 = $("#payment-form");
  f2.reset();
  f2.elements.subscriptionId.value = s2.id;
  f2.elements.dueDate.value = date;
  f2.elements.paidDate.value = today;
  f2.elements.amount.value = s2.amount;
  $("#payment-name").textContent = `${s2.name} \xB7 ${s2.currency}`;
  $("#payment-error").textContent = "";
  coverage();
  $("#payment-dialog").showModal();
}
function coverage() {
  const f2 = $("#payment-form"), s2 = data.subscriptions.find((s3) => s3.id === f2.elements.subscriptionId.value);
  if (!s2 || !f2.elements.dueDate.value) return;
  try {
    const end = nextBoundary(s2, f2.elements.dueDate.value);
    $("#coverage-preview").textContent = end ? `\u672C\u6B21\u4ED8\u6B3E\u8986\u76D6\uFF1A${f2.elements.dueDate.value} \u2192 ${end}\uFF08\u4E0D\u542B\u7ED3\u675F\u65E5\uFF09\u3002\u8BF7\u9009\u62E9\u539F\u8BA1\u5212\u4E2D\u7684\u65E5\u671F\u3002` : "\u4E00\u6B21\u6027\u4ED8\u6B3E\uFF0C\u4EC5\u8BB0\u5F55\u6240\u9009\u8BA1\u5212\u65E5\u671F\u3002";
  } catch {
    $("#coverage-preview").textContent = "\u8BF7\u9009\u62E9\u6709\u6548\u65E5\u671F";
  }
}
function day(date) {
  closeAll();
  chosenDay = date;
  $("#day-title").textContent = `${date} \xB7 \u5F53\u5929\u9879\u76EE`;
  const events = eventsFor(data.subscriptions, data.payments, date, date);
  $("#day-events").innerHTML = events.length ? events.map(eventHTML).join("") : empty("\u8FD9\u4E00\u5929\u8FD8\u6CA1\u6709\u9879\u76EE", "\u53EF\u4EE5\u5728\u8FD9\u4E2A\u65E5\u671F\u65B0\u589E\u8BA2\u9605\u3002");
  $("#day-dialog").showModal();
}
async function download(content, type, name) {
  if (Capacitor.isNativePlatform()) {
    const { uri } = await Filesystem.writeFile({ path: name, data: content, directory: Directory.Cache, encoding: Encoding.UTF8 });
    await Share.share({ title: name, files: [uri] });
    return;
  }
  const a = document.createElement("a"), url = URL.createObjectURL(new Blob([content], { type }));
  a.href = url;
  a.download = name;
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 3e4);
}
async function backup() {
  const b = await api("backup");
  await download(JSON.stringify(b, null, 2), "application/json", `\u8BA2\u9605\u65E5\u5386-\u5907\u4EFD-${today}.json`);
  backedUpRevision = b.revision;
  toast("\u5907\u4EFD\u6587\u4EF6\u5DF2\u751F\u6210\uFF0C\u8BF7\u786E\u8BA4\u5DF2\u4FDD\u5B58\u5230\u5B89\u5168\u4F4D\u7F6E");
}
document.addEventListener("click", (e) => {
  const close = e.target.closest("[data-close]");
  if (close) $(`#${close.dataset.close}`).close();
  const d = e.target.closest("[data-detail]");
  if (d) detail(d.dataset.detail, d.dataset.date);
  const c = e.target.closest("[data-day]");
  if (c) day(c.dataset.day);
  const undo = e.target.closest("[data-undo]");
  if (undo && confirm("\u64A4\u9500\u8FD9\u7B14\u4ED8\u6B3E\u8BB0\u5F55\uFF1F\u672C\u5468\u671F\u53EF\u80FD\u91CD\u65B0\u663E\u793A\u4E3A\u9884\u8BA1\u6263\u6B3E\u3002")) mutate("payments/delete", { id: undo.dataset.undo }).then(() => toast("\u5DF2\u64A4\u9500\u4ED8\u6B3E")).catch((e2) => toast(e2.message));
});
$$("[data-tab]").forEach((b) => b.onclick = () => switchTab(b.dataset.tab));
$("#refresh").onclick = () => load().then(() => toast("\u5DF2\u91CD\u65B0\u8BFB\u53D6\u672C\u673A\u8BB0\u5F55")).catch((e) => toast(e.message));
$("#add-subscription").onclick = () => editor();
$("#day-add").onclick = () => editor(null, chosenDay);
$("#prev-month").onclick = () => {
  if (month <= "1900-01-01") return;
  month = shiftMonths(month, -1);
  renderCalendar();
};
$("#next-month").onclick = () => {
  if (month >= "2200-12-01") return;
  month = shiftMonths(month, 1);
  renderCalendar();
};
$("#today").onclick = () => {
  today = localToday();
  month = today.slice(0, 7) + "-01";
  render();
};
for (const id of ["search", "filter-category", "filter-status"]) $(`#${id}`).addEventListener("input", renderList);
$("#subscription-form").elements.cycle.onchange = cycleChanged;
$("#subscription-form").elements.status.onchange = cycleChanged;
$("#subscription-form").onsubmit = async (e) => {
  e.preventDefault();
  const f2 = e.target, b = Object.fromEntries(new FormData(f2));
  b.amount = Number(b.amount);
  b.autoRenew = f2.elements.autoRenew.checked;
  b.customDays = Number(b.customDays);
  b.reminders = $$('[name="reminder"]:checked').map((el) => Number(el.value));
  if (!b.id) delete b.id;
  const btn = f2.querySelector('[type="submit"]');
  btn.disabled = true;
  try {
    await mutate("subscriptions", { subscription: b });
    closeAll();
    toast("\u8BA2\u9605\u5DF2\u4FDD\u5B58\u5230\u6B64\u8BBE\u5907");
  } catch (e2) {
    $("#editor-error").textContent = e2.message;
  } finally {
    btn.disabled = false;
  }
};
$("#payment-form").elements.dueDate.onchange = coverage;
$("#payment-form").onsubmit = async (e) => {
  e.preventDefault();
  const b = Object.fromEntries(new FormData(e.target));
  b.amount = Number(b.amount);
  const btn = e.target.querySelector('[type="submit"]');
  btn.disabled = true;
  try {
    await mutate("payments", b);
    closeAll();
    toast("\u5B9E\u9645\u4ED8\u6B3E\u5DF2\u8BB0\u5F55");
  } catch (e2) {
    $("#payment-error").textContent = e2.message;
  } finally {
    btn.disabled = false;
  }
};
$("#export-json").onclick = () => backup().catch((e) => toast(e.message));
$("#export-ics").onclick = async () => {
  try {
    await download(makeICS(data.subscriptions, data.payments, today, addDays(shiftMonths(today, 12), -1)), "text/calendar;charset=utf-8", `\u8BA2\u9605\u63D0\u9192-${today}.ics`);
    toast("\u5DF2\u5BFC\u51FA\u9759\u6001\u65E5\u5386\uFF1B\u66F4\u65B0\u524D\u8BF7\u5148\u6E05\u7406\u65E7\u4E13\u7528\u65E5\u5386");
  } catch (e) {
    toast(e.message);
  }
};
$("#import-json").onclick = () => $("#import-file").click();
$("#import-file").onchange = async (e) => {
  const file = e.target.files[0];
  if (!file) return;
  try {
    if (file.size > 8 * 1024 * 1024) throw Error("\u6587\u4EF6\u6700\u591A 8 MB");
    const b = JSON.parse(await file.text());
    migrate(b);
    pendingBackup = b;
    $("#import-preview").hidden = false;
    $("#import-preview").innerHTML = `<div class="banner">\u51C6\u5907\u5BFC\u5165 ${b.subscriptions.length} \u4E2A\u8BA2\u9605\u3001${b.payments.length} \u7B14\u4ED8\u6B3E\u3002\u6B64\u8BBE\u5907\u7684\u5F53\u524D\u6570\u636E\u5C06\u88AB\u66FF\u6362\u3002<div class="button-row"><button id="before-import" class="outline">1. \u5148\u5BFC\u51FA\u5F53\u524D\u5907\u4EFD</button><button id="confirm-import" class="danger-button">2. \u786E\u8BA4\u66FF\u6362\u5168\u90E8\u8BB0\u5F55</button><button id="cancel-import" class="text-button">\u53D6\u6D88</button></div></div>`;
    $("#before-import").onclick = () => backup().catch((e2) => toast(e2.message));
    $("#cancel-import").onclick = () => {
      $("#import-preview").hidden = true;
      pendingBackup = null;
    };
    $("#confirm-import").onclick = async () => {
      if (backedUpRevision !== data.revision) return toast("\u8BF7\u5148\u70B9\u51FB\u201C\u5148\u5BFC\u51FA\u5F53\u524D\u5907\u4EFD\u201D\uFF0C\u5E76\u786E\u8BA4\u6587\u4EF6\u5DF2\u7ECF\u4FDD\u5B58");
      if (!confirm("\u786E\u8BA4\u5DF2\u4FDD\u5B58\u5F53\u524D\u5907\u4EFD\uFF0C\u5E76\u5B8C\u6574\u66FF\u6362\u6B64\u8BBE\u5907\u6570\u636E\uFF1F\u5176\u4ED6\u8BBE\u5907\u4E0D\u53D7\u5F71\u54CD\u3002")) return;
      try {
        await mutate("import", { backup: pendingBackup });
        $("#import-preview").hidden = true;
        pendingBackup = null;
        toast("\u5907\u4EFD\u5DF2\u5B8C\u6574\u5BFC\u5165");
      } catch (e2) {
        toast(e2.message);
      }
    };
  } catch (e2) {
    toast(e2.message);
  } finally {
    e.target.value = "";
  }
};
document.addEventListener("visibilitychange", () => {
  if (!document.hidden && !$("dialog[open]")) load().catch((e) => toast(e.message));
});
if ("serviceWorker" in navigator && ["https:", "http:"].includes(location.protocol) && !window.electronApp && !Capacitor.isNativePlatform()) navigator.serviceWorker.register("./sw.js").catch((e) => toast("\u79BB\u7EBF\u8D44\u6E90\u672A\u7F13\u5B58\uFF1A" + e.message));
try {
  await load();
  requestPersistence();
} catch (e) {
  $("#storage-error").hidden = false;
  $("#storage-error").textContent = "\u672A\u80FD\u8BFB\u53D6\u672C\u5730\u6570\u636E\uFF1A" + e.message + " \u539F\u6570\u636E\u672A\u6E05\u7A7A\u3002\u8BF7\u5148\u5BFC\u51FA/\u4FDD\u5B58\u539F\u5907\u4EFD\uFF0C\u52FF\u6E05\u7406\u5E94\u7528\u6570\u636E\u3002";
  $("#add-subscription").disabled = true;
  toast(e.message);
}
/*! Bundled license information:

@capacitor/core/dist/index.js:
  (*! Capacitor: https://capacitorjs.com/ - MIT License *)
*/
